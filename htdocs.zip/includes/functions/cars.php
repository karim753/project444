<?php

/**
 * Toggle like status for a car
 * @param PDO $pdo Database connection object
 * @param int $carId ID of the car
 * @param int $userId ID of the user
 * @return array Result with status and action (liked/unliked)
 */
function toggleCarLike($pdo, $carId, $userId) {
    try {
        // Check if like already exists
        $stmt = $pdo->prepare("SELECT id FROM car_likes WHERE car_id = ? AND user_id = ?");
        $stmt->execute([$carId, $userId]);
        
        if ($stmt->fetch()) {
            // Unlike
            $stmt = $pdo->prepare("DELETE FROM car_likes WHERE car_id = ? AND user_id = ?");
            $stmt->execute([$carId, $userId]);
            return ['status' => 'success', 'action' => 'unliked'];
        } else {
            // Like
            $stmt = $pdo->prepare("INSERT INTO car_likes (car_id, user_id) VALUES (?, ?)");
            $stmt->execute([$carId, $userId]);
            return ['status' => 'success', 'action' => 'liked'];
        }
    } catch (PDOException $e) {
        error_log("Error toggling car like: " . $e->getMessage());
        return ['status' => 'error', 'message' => 'Could not update like status'];
    }
}

/**
 * Check if a car is liked by user
 * @param PDO $pdo Database connection object
 * @param int $carId ID of the car
 * @param int $userId ID of the user
 * @return bool Whether the car is liked by the user
 */
function isCarLikedByUser($pdo, $carId, $userId) {
    if (!$userId) return false;
    
    try {
        $stmt = $pdo->prepare("SELECT id FROM car_likes WHERE car_id = ? AND user_id = ?");
        $stmt->execute([$carId, $userId]);
        return (bool)$stmt->fetch();
    } catch (PDOException $e) {
        error_log("Error checking if car is liked: " . $e->getMessage());
        return false;
    }
}

/**
 * Get like count for a car
 * @param PDO $pdo Database connection object
 * @param int $carId ID of the car
 * @return int Number of likes
 */
function getCarLikeCount($pdo, $carId) {
    try {
        error_log("Getting like count for car ID: " . $carId);
        
        // Controleer of de tabel bestaat
        $tableExists = $pdo->query("SHOW TABLES LIKE 'car_likes'")->rowCount() > 0;
        if (!$tableExists) {
            error_log("Tabel car_likes bestaat niet");
            return 0;
        }
        
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM car_likes WHERE car_id = ?");
        $stmt->execute([$carId]);
        $result = $stmt->fetch();
        
        $count = (int)($result['count'] ?? 0);
        error_log("Found $count likes for car ID: $carId");
        
        return $count;
    } catch (PDOException $e) {
        $errorMsg = "Error getting car like count: " . $e->getMessage();
        error_log($errorMsg);
        return 0;
    }
}

/**
 * Haal alle auto's op uit de database
 * @param PDO $pdo Database connectie object
 * @return array Lijst van auto's
 */
function getAllCars($pdo) {
    try {
        $query = "SELECT * FROM cars ORDER BY created_at DESC";
        $stmt = $pdo->query($query);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Fout bij ophalen auto's: " . $e->getMessage());
        throw $e;
    }
}

/**
 * Haal een specifieke auto op basis van ID
 * @param PDO $pdo Database connectie object
 * @param int $id Auto ID
 * @return array|false Auto gegevens of false als niet gevonden
 */
function getCarById($pdo, $id) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM cars WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Fout bij ophalen auto met ID $id: " . $e->getMessage());
        return false;
    }
}

/**
 * Voeg een nieuwe auto toe aan de database
 * @param PDO $pdo Database connectie object
 * @param array $carData Associatieve array met auto gegevens
 * @return bool True bij succes, false bij fout
 */
function addCar($pdo, $carData) {
    try {
        $query = "INSERT INTO cars (brand, model, year, price, mileage, fuel_type, transmission, image_path) 
                 VALUES (:brand, :model, :year, :price, :mileage, :fuel_type, :transmission, :image_path)";
        
        $stmt = $pdo->prepare($query);
        return $stmt->execute([
            ':brand' => $carData['brand'] ?? null,
            ':model' => $carData['model'] ?? null,
            ':year' => $carData['year'] ?? null,
            ':price' => $carData['price'] ?? null,
            ':mileage' => $carData['mileage'] ?? null,
            ':fuel_type' => $carData['fuel_type'] ?? null,
            ':transmission' => $carData['transmission'] ?? null,
            ':image_path' => $carData['image_path'] ?? null
        ]);
    } catch (PDOException $e) {
        error_log("Fout bij toevoegen auto: " . $e->getMessage());
        return false;
    }
}
