/**
 * car-detail.js
 * 
 * Verwerking van het reserveringsformulier en like-functionaliteit
 */

// Functie om de like-knop bij te werken
function updateLikeButton(button, isLiked, likeCount) {
    const icon = button.querySelector('i');
    const countElement = button.querySelector('.like-count');
    
    if (isLiked) {
        button.classList.add('active');
        icon.classList.remove('bi-heart');
        icon.classList.add('bi-heart-fill', 'text-danger');
    } else {
        button.classList.remove('active');
        icon.classList.remove('bi-heart-fill', 'text-danger');
        icon.classList.add('bi-heart');
    }
    
    if (countElement) {
        countElement.textContent = likeCount || '';
    }
}

// Like-knop functionaliteit
function setupLikeButton(button) {
    const carId = button.dataset.carId;
    if (!carId) return;
    
    // Haal initiële like status op
    fetch(`/actions/get-like-status.php?car_id=${carId}`)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                updateLikeButton(button, data.isLiked, data.likeCount);
            }
        })
        .catch(console.error);
    
    // Voeg event listener toe voor klikken
    button.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Voorkom dubbele klikken
        if (button.classList.contains('loading')) return;
        button.classList.add('loading');
        
        const formData = new FormData();
        formData.append('car_id', carId);
        
        fetch('/actions/toggle-car-like.php', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                updateLikeButton(button, data.action === 'liked', data.like_count);
            } else {
                throw new Error(data.message || 'Er is een fout opgetreden');
            }
        })
        .catch(error => {
            console.error('Fout bij liken:', error);
            alert('Fout: ' + (error.message || 'Kon de like niet verwerken'));
        })
        .finally(() => {
            button.classList.remove('loading');
        });
    });
}

document.addEventListener('DOMContentLoaded', function() {
    // Initialiseer like knoppen
    document.querySelectorAll('.like-button').forEach(button => {
        setupLikeButton(button);
    });
    
    const form = document.getElementById('reserveringForm');
    
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Verkrijg de formuliergegevens
            const formData = new FormData(form);
            const submitButton = form.querySelector('button[type="submit"]');
            const submitButtonText = submitButton ? submitButton.innerHTML : '';
            const baseUrl = window.location.protocol + '//' + window.location.host;
            
            // Voeg eventuele extra velden toe die niet in het formulier zitten
            const carId = document.querySelector('input[name="car_id"]')?.value;
            if (carId) {
                formData.append('car_id', carId);
            }
            
            // Toon laadstatus
            if (submitButton) {
                submitButton.disabled = true;
                submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Bezig met verwerken...';
            }
            
            // Stuur de gegevens naar de server
            fetch('/actions/create_rental.php', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(async response => {
                const data = await response.json().catch(() => ({}));
                
                if (!response.ok) {
                    // Als de response niet OK is, gooi een fout met de status en eventuele foutmelding
                    const error = new Error(data.message || `HTTP-fout! Status: ${response.status}`);
                    error.status = response.status;
                    error.data = data;
                    throw error;
                }
                
                return data;
            })
            .then(data => {
                if (data.success) {
                    // Toon succesbericht en ga daarna door
                    const successMessage = document.createElement('div');
                    successMessage.className = 'alert alert-success mt-3';
                    successMessage.innerHTML = `
                        <i class="bi bi-check-circle-fill me-2"></i>
                        ${data.message || 'Reservering succesvol geplaatst!'}
                        <div class="small mt-2">Je wordt nu doorgestuurd naar je accountoverzicht...</div>
                    `;
                    form.parentNode.insertBefore(successMessage, form.nextSibling);
                    
                    // Verberg het formulier
                    form.style.display = 'none';
                    
                    // Doorsturen naar accountpagina
                    setTimeout(() => {
                        window.location.href = baseUrl + '/pages/mijn-account.php';
                    }, 2000);
                } else {
                    throw new Error(data.message || 'Er is een onverwachte fout opgetreden.');
                }
            })
            .catch(error => {
                console.error('Foutdetails:', error);
                
                // Herstel de knop
                if (submitButton) {
                    submitButton.disabled = false;
                    submitButton.innerHTML = submitButtonText;
                }
                
                // Toon foutmelding boven het formulier
                let errorMessage = 'Er is een fout opgetreden bij het verwerken van je verzoek.';
                let errorDetails = '';
                
                // Verwijder eventuele eerdere foutmeldingen
                const existingAlerts = form.querySelectorAll('.alert');
                existingAlerts.forEach(alert => alert.remove());
                
                // Bepaal het juiste foutbericht op basis van de fout
                if (error.status) {
                    switch (error.status) {
                        case 400:
                            errorMessage = 'Ongeldig verzoek';
                            errorDetails = 'Controleer of alle velden correct zijn ingevuld. ' + 
                                         (error.data?.message || '');
                            break;
                            
                        case 401:
                            errorMessage = 'Niet ingelogd';
                            errorDetails = 'Je moet ingelogd zijn om een reservering te maken.';
                            window.location.href = baseUrl + '/inloggen.php?redirect=' + encodeURIComponent(window.location.pathname);
                            return;
                            
                        case 403:
                            errorMessage = 'Geen toestemming';
                            errorDetails = 'Je hebt geen toestemming om deze actie uit te voeren.';
                            break;
                            
                        case 404:
                            errorMessage = 'Auto niet gevonden';
                            errorDetails = 'De geselecteerde auto kon niet worden gevonden.';
                            break;
                            
                        case 409:
                            errorMessage = 'Conflict';
                            errorDetails = 'Deze auto is al gereserveerd in de geselecteerde periode.';
                            break;
                            
                        case 500:
                            errorMessage = 'Serverfout';
                            errorDetails = 'Er is een fout opgetreden bij het verwerken van je verzoek. Probeer het later opnieuw.';
                            break;
                            
                        default:
                            errorMessage = `Fout (${error.status})`;
                            errorDetails = error.data?.message || error.message;
                    }
                } else if (error.message) {
                    errorDetails = error.message;
                }
                
                // Maak een mooie foutmelding
                const errorAlert = document.createElement('div');
                errorAlert.className = 'alert alert-danger';
                errorAlert.innerHTML = `
                    <div class="d-flex align-items-center">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i>
                        <strong>${errorMessage}</strong>
                    </div>
                    ${errorDetails ? `<div class="mt-2">${errorDetails}</div>` : ''}
                `;
                
                // Voeg de foutmelding toe boven het formulier
                form.parentNode.insertBefore(errorAlert, form);
                
                // Scroll naar de foutmelding
                errorAlert.scrollIntoView({ behavior: 'smooth', block: 'center' });
            });
        });
    }
});
