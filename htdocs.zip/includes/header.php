<?php session_start(); ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="ISO-8859-1">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Rydr</title>
    <link rel="stylesheet" href="/assets/css/main.css">
    <link rel="icon" type="image/png" href="/assets/images/favicon.ico" sizes="32x32">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,200..800;1,200..800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
</head>
<body>
<div class="topbar">
    <div class="logo">
        <a href="/">
            Rydr.
        </a>
    </div>
    <div class="search-container">
        <form action="/zoeken" method="get" class="search-form">
            <div class="search-input-wrapper">
                <input 
                    type="search" 
                    name="q" 
                    id="searchInput" 
                    placeholder="Welke auto wilt u huren?" 
                    value="<?= htmlspecialchars($_GET['q'] ?? '') ?>"
                    autocomplete="off"
                    aria-autocomplete="list"
                    aria-haspopup="true"
                >
                <button type="submit" class="search-button">
                    <img src="/assets/images/icons/search-normal.svg" alt="Zoeken" class="search-icon">
                </button>
                <div id="searchSuggestions" class="search-suggestions"></div>
            </div>
        </form>
    </div>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('searchInput');
        const searchSuggestions = document.getElementById('searchSuggestions');
        let searchTimeout;

        searchInput.addEventListener('input', function(e) {
            const query = e.target.value.trim();
            
            // Clear previous timeout and suggestions
            clearTimeout(searchTimeout);
            searchSuggestions.innerHTML = '';
            searchSuggestions.style.display = 'none';
            
            if (query.length < 2) return;
            
            // Set a small delay before making the request
            searchTimeout = setTimeout(() => {
                fetch(`/actions/search_suggestions.php?q=${encodeURIComponent(query)}`)
                    .then(response => response.json())
                    .then(suggestions => {
                        if (suggestions.length > 0) {
                            const suggestionsHTML = suggestions.map(suggestion => 
                                `<div class="suggestion-item" data-suggestion="${suggestion}">
                                    ${suggestion}
                                </div>`
                            ).join('');
                            
                            searchSuggestions.innerHTML = suggestionsHTML;
                            searchSuggestions.style.display = 'block';
                        }
                    })
                    .catch(error => {
                        console.error('Error fetching suggestions:', error);
                    });
            }, 200);
        });
        
        // Handle click on suggestion
        searchSuggestions.addEventListener('click', function(e) {
            if (e.target.classList.contains('suggestion-item')) {
                searchInput.value = e.target.getAttribute('data-suggestion');
                searchInput.focus();
                searchSuggestions.style.display = 'none';
                e.target.closest('form').submit();
            }
        });
        
        // Close suggestions when clicking outside
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.search-input-wrapper')) {
                searchSuggestions.style.display = 'none';
            }
        });
        
        // Handle keyboard navigation
        searchInput.addEventListener('keydown', function(e) {
            if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                e.preventDefault();
                const items = searchSuggestions.querySelectorAll('.suggestion-item');
                if (items.length === 0) return;
                
                const current = document.activeElement;
                let index = Array.from(items).indexOf(current);
                
                if (e.key === 'ArrowDown') {
                    index = (index + 1) % items.length;
                } else {
                    index = (index - 1 + items.length) % items.length;
                }
                
                items[index].focus();
            } else if (e.key === 'Enter' && document.activeElement.classList.contains('suggestion-item')) {
                document.activeElement.click();
            }
        });
    });
    </script>
    <nav>
        <ul>
            <li><a href="/">Home</a></li>
            <li><a href="aanbod">Ons aanbod</a></li>
            <li><a href="/over-ons">Over ons</a></li>
        </ul>
    </nav>
    <div class="menu">
        <?php if(isset($_SESSION['user_id'])){ ?>
        <div class="account">
            <img src="/assets/images/Profil.png" alt="Profiel" onerror="this.src='/assets/images/placeholder.jpg'">
            <div class="account-dropdown">
                <ul>
                    <li><img src="/assets/images/icons/setting.svg" alt="Instellingen"><a href="/mijn-account">Mijn account</a></li>
                    <li><img src="/assets/images/icons/logout.svg" alt="Uitloggen"><a href="/actions/logout.php">Uitloggen</a></li>
                </ul>
            </div>
        </div>
        <?php }else{ ?>
            <a href="#" class="button-primary" id="startHurenBtn">Start met huren</a>
        <?php } ?>
    </div>
</div>

<!-- Auth Modal -->
<div id="authModal" class="modal">
    <div class="modal-content">
        <span class="close-modal">&times;</span>
        <h2>Welkom bij Rydr</h2>
        <p>Kies een optie om verder te gaan</p>
        <div class="auth-buttons">
            <a href="/pages/login-form.php" class="button-primary">Inloggen</a>
            <a href="/register-form" class="button-secondary">Registreren</a>
        </div>
    </div>
</div>

<style>
.search-container {
    position: relative;
    max-width: 400px;
    width: 100%;
}

.search-input-wrapper {
    position: relative;
    width: 100%;
}

.search-form {
    width: 100%;
}

.search-input-wrapper input[type="search"] {
    width: 100%;
    padding: 10px 40px 10px 15px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 14px;
    box-sizing: border-box;
}

.search-button {
    position: absolute;
    right: 80px;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    cursor: pointer;
    padding: 5px;
}

.search-suggestions {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    background: white;
    border: 1px solid #ddd;
    border-top: none;
    border-radius: 0 0 4px 4px;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    max-height: 300px;
    overflow-y: auto;
    z-index: 1000;
    display: none;
}

.suggestion-item {
    padding: 10px 15px;
    cursor: pointer;
    transition: background-color 0.2s;
    color: #333;
    text-align: left;
}

.suggestion-item:hover,
.suggestion-item:focus {
    background-color: #f5f5f5;
    outline: none;
}

.suggestion-item:not(:last-child) {
    border-bottom: 1px solid #eee;
}

/* Make search input more visible when focused */
.search-input-wrapper:focus-within input[type="search"] {
    border-color: #4a90e2;
    box-shadow: 0 0 0 2px rgba(74, 144, 226, 0.2);
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .search-container {
        max-width: 100%;
        padding: 0 10px;
    }
}

.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5);
    overflow: auto;
}

.modal-content {
    background-color: white;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    padding: 2rem;
    border-radius: 8px;
    width: 90%;
    max-width: 400px;
    text-align: center;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.close-modal {
    position: absolute;
    right: 1rem;
    top: 0.5rem;
    font-size: 1.5rem;
    cursor: pointer;
}

.auth-buttons {
    display: flex;
    flex-direction: row;
    justify-content: center;
    gap: 1rem;
    margin-top: 1.5rem;
    flex-wrap: wrap;
}

.auth-buttons a {
    flex: 1;
    min-width: 120px;
    text-align: center;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById('authModal');
    const startHurenBtn = document.getElementById('startHurenBtn');
    const closeBtn = document.querySelector('.close-modal');

    if (startHurenBtn) {
        startHurenBtn.addEventListener('click', function(e) {
            e.preventDefault();
            modal.style.display = 'block';
        });
    }

    if (closeBtn) {
        closeBtn.addEventListener('click', function() {
            modal.style.display = 'none';
        });
    }

    window.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });
});
</script>
<div class="content">