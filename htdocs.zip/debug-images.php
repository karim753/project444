<?php
require_once 'database/connection.php';

// Check database connection
try {
    // Eerst de structuur van de tabel bekijken
    $stmt = $pdo->query("DESCRIBE cars");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "<h2>Kolommen in de auto's tabel:</h2>";
    echo "<pre>";
    print_r($columns);
    echo "</pre>";
    
    // Bouw een query met de beschikbare kolommen
    $selectFields = array_intersect(['id', 'brand', 'model', 'merk', 'type', 'foto', 'image', 'image_path', 'image_url'], $columns);
    if (empty($selectFields)) {
        $selectFields = ['*']; // Als geen van de verwachte velden bestaan, haal alles op
    }
    
    $query = "SELECT " . implode(', ', $selectFields) . " FROM cars";
    $cars = $pdo->query($query)->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h2>Auto's in de database:</h2>";
    echo "<pre>";
    print_r($cars);
    echo "</pre>";
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

// List all files in assets/images
echo "<h2>Files in assets/images:</h2>";
$files = [];
$dir = new RecursiveDirectoryIterator('assets/images/');
$iterator = new RecursiveIteratorIterator($dir);

foreach ($iterator as $file) {
    if ($file->isFile()) {
        $files[] = $file->getPathname();
    }
}

echo "<pre>";
print_r($files);
echo "</pre>";

// Show server document root
echo "<h2>Server Information:</h2>";
echo "Document Root: " . $_SERVER['DOCUMENT_ROOT'] . "<br>";
?>

<h2>Test Image Paths:</h2>
<?php
// Test some common paths
$testPaths = [
    'assets/images/placeholder-car.png',
    'assets/images/car-rent-header-image-1.png',
    'assets/images/car-rent-header-image-2.png'
];

foreach ($testPaths as $path) {
    $fullPath = $_SERVER['DOCUMENT_ROOT'] . '/' . ltrim($path, '/');
    echo "Checking: " . htmlspecialchars($path) . " - ";
    echo file_exists($fullPath) ? "<span style='color:green'>Exists</span>" : "<span style='color:red'>Not found</span>";
    echo " (Full path: " . htmlspecialchars($fullPath) . ")<br>";
}
?>
