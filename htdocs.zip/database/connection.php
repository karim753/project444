<?php
// Database configuratie
$host = 'localhost';
$db   = 'project42';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

// DSN (Data Source Name)
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

// PDO opties
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
    PDO::ATTR_PERSISTENT         => true,  // Voor betere prestaties
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
];

try {
    // Maak een nieuwe PDO instantie
    $pdo = new PDO($dsn, $user, $pass, $options);
    
    // Test de verbinding
    $pdo->query('SELECT 1');
    
} catch (PDOException $e) {
    // Log de fout voor beheerders
    error_log("Database fout: " . $e->getMessage());
    
    // Toon een gebruiksvriendelijk bericht
    if (!headers_sent()) {
        header('HTTP/1.1 503 Service Unavailable');
        header('Content-Type: application/json; charset=utf-8');
    }
    
    die(json_encode([
        'error' => true,
        'message' => 'Er is een fout opgetreden bij het verbinden met de database. Probeer het later opnieuw.'
    ]));
}

// Functie om de database te controleren
function checkDatabaseConnection() {
    global $pdo;
    try {
        $pdo->query('SELECT 1');
        return true;
    } catch (PDOException $e) {
        return false;
    }
}
?>
