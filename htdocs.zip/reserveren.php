<?php
require_once __DIR__ . "/includes/header.php";
require_once __DIR__ . "/database/connection.php";
require_once __DIR__ . "/includes/functions/cars.php";

// Controleer of het formulier is verzonden
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $carId = $_POST['car_id'] ?? null;
    $startDatum = $_POST['start_datum'] ?? '';
    $eindDatum = $_POST['eind_datum'] ?? '';
    
    // Basisvalidatie
    if (!$carId || !$startDatum || !$eindDatum) {
        header("Location: /pages/404.php");
        exit();
    }
    
    try {
        // Haal auto-informatie op
        $car = getCarById($pdo, $carId);
        
        if (!$car) {
            throw new Exception("Auto niet gevonden");
        }
        
        // Bereken het aantal dagen
        $start = new DateTime($startDatum);
        $eind = new DateTime($eindDatum);
        $aantalDagen = $eind->diff($start)->days;
        
        if ($aantalDagen < 1) {
            throw new Exception("Ongeldige periode geselecteerd");
        }
        
        // Bereken totaalbedrag
        $totaal = $aantalDagen * $car['price'];
        
        // Toon bevestigingspagina
        ?>
        <main class="reservering-bevestiging">
            <div class="container">
                <h1>Reservering bevestigen</h1>
                <div class="reservering-overzicht">
                    <h2>Jouw reservering</h2>
                    <div class="auto-info">
                        <h3><?= htmlspecialchars($car['brand'] . ' ' . $car['model']) ?></h3>
                        <p>Periode: <?= $start->format('d-m-Y') ?> t/m <?= $eind->format('d-m-Y') ?></p>
                        <p>Aantal dagen: <?= $aantalDagen ?></p>
                        <p class="prijs">Totaal: €<?= number_format($totaal, 2, ',', '.') ?></p>
                    </div>
                    <form method="post" action="/afrekenen.php">
                        <input type="hidden" name="car_id" value="<?= $carId ?>">
                        <input type="hidden" name="start_datum" value="<?= $startDatum ?>">
                        <input type="hidden" name="eind_datum" value="<?= $eindDatum ?>">
                        <button type="submit" class="button-primary">Nu betalen</button>
                    </form>
                </div>
            </div>
        </main>
        <?php
        
    } catch (Exception $e) {
        error_log("Fout bij reserveren: " . $e->getMessage());
        header("Location: /pages/500.php");
        exit();
    }
    
} else {
    // Als iemand rechtstreeks naar deze pagina gaat zonder formulier
    header("Location: /pages/404.php");
    exit();
}

require_once __DIR__ . "/includes/footer.php";
?>
