<?php
require_once __DIR__ . "/../database/connection.php";
require_once __DIR__ . "/../includes/functions/cars.php";

header('Content-Type: application/json');

// Log incoming request
error_log("toggle-car-like.php called with: " . print_r($_POST, true));

// Ensure user is logged in
session_start();
if (!isset($_SESSION['user_id'])) {
    $error = 'Gebruiker niet ingelogd';
    error_log($error);
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Je moet ingelogd zijn om auto\'s te kunnen liken']);
    exit();
}

// Validate input
$carId = filter_input(INPUT_POST, 'car_id', FILTER_VALIDATE_INT);
$userId = $_SESSION['user_id'];

error_log("User ID: $userId, Car ID: $carId");

if (!$carId) {
    $error = 'Ongeldig auto ID: ' . ($_POST['car_id'] ?? 'leeg');
    error_log($error);
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => $error]);
    exit();
}

try {
    // Controleer of de auto bestaat
    $stmt = $pdo->prepare("SELECT id FROM cars WHERE id = ?");
    $stmt->execute([$carId]);
    if (!$stmt->fetch()) {
        throw new Exception("Auto met ID $carId bestaat niet");
    }
    
    $result = toggleCarLike($pdo, $carId, $userId);
    error_log("Toggle result: " . print_r($result, true));
    
    if ($result['status'] === 'error') {
        throw new Exception($result['message'] ?? 'Onbekende fout bij het liken van de auto');
    }
    
    $likeCount = getCarLikeCount($pdo, $carId);
    $result['like_count'] = $likeCount;
    
    error_log("Like count for car $carId: $likeCount");
    
    echo json_encode($result);
} catch (Exception $e) {
    $errorMsg = "Error in toggle-car-like.php: " . $e->getMessage();
    error_log($errorMsg);
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => $errorMsg]);
}
