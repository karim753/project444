<?php
session_start();
require_once __DIR__ . "/../database/connection.php";

// Controleer of de database beschikbaar is
if (!function_exists('checkDatabaseConnection') || !checkDatabaseConnection()) {
    $_SESSION['error'] = "Kan geen verbinding maken met de database. Probeer het later opnieuw.";
    header('Location: /pages/login-form.php');
    exit();
}

// Controleer of het formulier is ingediend
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error'] = "Ongeldig verzoek.";
    header('Location: /pages/login-form.php');
    exit();
}

// Valideer invoer
$email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
$password = $_POST['password'] ?? '';

if (!$email || empty($password)) {
    $_SESSION['error'] = "Vul een geldig e-mailadres en wachtwoord in.";
    $_SESSION['email'] = $_POST['email'] ?? '';
    header('Location: /pages/login-form.php');
    exit();
}

try {
    // Zoek gebruiker op e-mail
    $select_user = $pdo->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
    $select_user->bindParam(":email", $email);
    $select_user->execute();
    $user = $select_user->fetch(PDO::FETCH_ASSOC);

    // Controleer of gebruiker bestaat en wachtwoord klopt
    if ($user && password_verify($password, $user['password'])) {
        // Inloggen succesvol
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['email'] = $user['email'];
        
        // Verwijder eventuele foutmeldingen
        unset($_SESSION['error']);
        
        // Doorsturen naar de oorspronkelijke pagina of home
        $redirect = $_SESSION['redirect_after_login'] ?? '/';
        unset($_SESSION['redirect_after_login']);
        
        header('Location: ' . $redirect);
        exit();
    } else {
        // Onjuiste inloggegevens
        $_SESSION['error'] = "Ongeldig e-mailadres of wachtwoord.";
        $_SESSION['email'] = $email;
        header('Location: /pages/login-form.php');
        exit();
    }
} catch (PDOException $e) {
    // Database fout
    error_log("Login error: " . $e->getMessage());
    $_SESSION['error'] = "Er is een fout opgetreden. Probeer het later opnieuw.";
    header('Location: /pages/login-form.php');
    exit();
}
