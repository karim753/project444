<?php
session_start();
require_once __DIR__ . "/../database/connection.php";

// Valideer invoer
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error'] = "Ongeldig verzoek.";
    header("Location: /pages/register-form.php");
    exit();
}

// Valideer vereiste velden
if (empty($_POST['email']) || empty($_POST['password']) || empty($_POST['confirm_password'])) {
    $_SESSION['error'] = "Alle velden zijn verplicht.";
    $_SESSION['email'] = htmlspecialchars($_POST['email'] ?? '');
    header("Location: /pages/register-form.php");
    exit();
}

$email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
$password = $_POST['password'];
$confirm_password = $_POST['confirm_password'];

// Valideer e-mail
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $_SESSION['error'] = "Ongeldig e-mailadres formaat.";
    $_SESSION['email'] = htmlspecialchars($email);
    header("Location: /pages/register-form.php");
    exit();
}

// Controleer wachtwoordlengte
if (strlen($password) < 8) {
    $_SESSION['error'] = "Wachtwoord moet minimaal 8 tekens lang zijn.";
    $_SESSION['email'] = htmlspecialchars($email);
    header("Location: /pages/register-form.php");
    exit();
}

// Controleer of wachtwoorden overeenkomen
if ($password !== $confirm_password) {
    $_SESSION['error'] = "Wachtwoorden komen niet overeen.";
    $_SESSION['email'] = htmlspecialchars($email);
    header("Location: /pages/register-form.php");
    exit();
}

try {
    // Controleer of e-mail al bestaat
    $check_user = $pdo->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
    $check_user->bindParam(":email", $email);
    $check_user->execute();

    if ($check_user->rowCount() > 0) {
        $_SESSION['error'] = "Dit e-mailadres is al in gebruik.";
        $_SESSION['email'] = htmlspecialchars($email);
        header("Location: /pages/register-form.php");
        exit();
    }

    // Wachtwoord hashen en gebruiker aanmaken
    $options = ['cost' => 12];
    $hashed_password = password_hash($password, PASSWORD_BCRYPT, $options);

    $stmt = $pdo->prepare("INSERT INTO users (email, password) VALUES (:email, :password)");
    $stmt->bindParam(":email", $email);
    $stmt->bindParam(":password", $hashed_password);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Registratie succesvol! Je kunt nu inloggen.";
        header("Location: /pages/login-form.php");
        exit();
    } else {
        throw new Exception("Er is een fout opgetreden bij het registreren.");
    }
} catch (Exception $e) {
    $_SESSION['error'] = "Er is een fout opgetreden. Probeer het later opnieuw.";
    $_SESSION['email'] = htmlspecialchars($email);
    error_log("Registration error: " . $e->getMessage());
    header("Location: /pages/register-form.php");
    exit();
}
