<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't show errors to users, but log them

require_once __DIR__ . '/../database/connection.php';

header('Content-Type: application/json');

$query = trim($_GET['q'] ?? '');
$suggestions = [];

if (strlen($query) < 2) {
    echo json_encode($suggestions);
    exit();
}

try {
    // Check if the cars table exists
    $tableCheck = $pdo->query("SHOW TABLES LIKE 'cars'");
    if ($tableCheck->rowCount() === 0) {
        throw new Exception("Cars table not found");
    }

    // Get available columns
    $columns = [];
    $columnStmt = $pdo->query("DESCRIBE cars");
    while ($row = $columnStmt->fetch(PDO::FETCH_ASSOC)) {
        $columns[] = $row['Field'];
    }

    // Define possible searchable columns
    $possibleColumns = ['brand', 'model', 'type'];
    $searchableColumns = array_intersect($possibleColumns, $columns);
    
    if (empty($searchableColumns)) {
        throw new Exception("No searchable columns found");
    }

    $searchTerm = $query . '%';
    $params = [':query' => $searchTerm];
    
    // Build the base query
    $queries = [];
    
    // 1. Search in brand and model
    if (in_array('brand', $searchableColumns) && in_array('model', $searchableColumns)) {
        $queries[] = "(
            SELECT DISTINCT CONCAT(brand, ' ', model) as suggestion 
            FROM cars 
            WHERE brand LIKE :query OR model LIKE :query
            GROUP BY brand, model
            LIMIT 5
        )";
    }
    
    // 2. Search in type
    if (in_array('type', $searchableColumns)) {
        $queries[] = "(
            SELECT DISTINCT CONCAT(brand, ' ', model, ' (', type, ')') as suggestion
            FROM cars 
            WHERE type LIKE :query
            GROUP BY brand, model, type
            LIMIT 3
        )";
    }
    
    // 3. Search in brand only
    if (in_array('brand', $searchableColumns)) {
        $queries[] = "(
            SELECT DISTINCT brand as suggestion
            FROM cars 
            WHERE brand LIKE :query
            LIMIT 3
        )";
    }
    
    if (empty($queries)) {
        throw new Exception("No valid search queries could be constructed");
    }
    
    // Combine all queries with UNION and limit total results
    $sql = implode("\nUNION\n", $queries) . "\nLIMIT 8";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $suggestions = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Fallback search if no results
    if (empty($suggestions) && in_array('brand', $searchableColumns) && in_array('model', $searchableColumns)) {
        $stmt = $pdo->prepare("
            SELECT DISTINCT CONCAT(brand, ' ', model) as suggestion 
            FROM cars 
            WHERE CONCAT(brand, ' ', model) LIKE :like_query
            LIMIT 5
        ");
        $stmt->execute([':like_query' => "%$query%"]);
        $suggestions = $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    
} catch (Exception $e) {
    error_log("Search suggestions error: " . $e->getMessage());
    // Return empty array on error
    $suggestions = [];
}

echo json_encode(array_values(array_unique($suggestions)));
