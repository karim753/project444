<?php
require_once __DIR__ . "/../database/connection.php";
require_once __DIR__ . "/../includes/functions/cars.php";

header('Content-Type: application/json');

// Valideer input
$carId = filter_input(INPUT_GET, 'car_id', FILTER_VALIDATE_INT);

if (!$carId) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Ongeldig auto ID']);
    exit();
}

try {
    // Maak database verbinding
    $pdo = new PDO('mysql:host=localhost;dbname=project42;charset=utf8mb4', 'root', '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    
    $isLiked = false;
    $likeCount = 0;
    
    // Controleer of gebruiker is ingelogd
    session_start();
    if (isset($_SESSION['user_id'])) {
        $isLiked = isCarLikedByUser($pdo, $carId, $_SESSION['user_id']);
    }
    
    // Haal het aantal likes op
    $likeCount = getCarLikeCount($pdo, $carId);
    
    echo json_encode([
        'status' => 'success',
        'isLiked' => $isLiked,
        'likeCount' => $likeCount
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error', 
        'message' => 'Er is een fout opgetreden bij het ophalen van de like status'
    ]);
    error_log("Error in get-like-status.php: " . $e->getMessage());
}
