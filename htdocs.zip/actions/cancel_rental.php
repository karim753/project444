<?php
// Simple error reporting
error_reporting(0);
session_start();

// Simple response function
function sendResponse($success, $message = '') {
    header('Content-Type: application/json');
    echo json_encode(['success' => $success, 'message' => $message]);
    exit();
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    sendResponse(false, 'Niet ingelogd');
}

// Get rental ID
$rentalId = $_POST['rental_id'] ?? null;
if (!$rentalId) {
    sendResponse(false, 'Geen reservering geselecteerd');
}

try {
    // Connect to database
    $pdo = new PDO('mysql:host=localhost;dbname=project42;charset=utf8mb4', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Delete the rental
    $stmt = $pdo->prepare("DELETE FROM car_rentals WHERE id = ? AND user_id = ?");
    $stmt->execute([$rentalId, $_SESSION['user_id']]);
    
    if ($stmt->rowCount() > 0) {
        sendResponse(true, 'Reservering verwijderd');
    } else {
        sendResponse(false, 'Kon reservering niet vinden of verwijderen');
    }
    
} catch (Exception $e) {
    sendResponse(false, 'Fout bij verwijderen: ' . $e->getMessage());
}
