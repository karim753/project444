<?php
// Start sessie
session_start();

// Controleer of het een AJAX-verzoek is
$isAjax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

// Functie om JSON response te sturen
function sendJsonResponse($success, $message = '', $redirect = '') {
    global $isAjax;
    
    $response = [
        'success' => $success,
        'message' => $message,
        'redirect' => $redirect
    ];
    
    if ($isAjax) {
        header('Content-Type: application/json');
        echo json_encode($response);
        exit();
    } else {
        if ($success && $redirect) {
            header("Location: $redirect");
        } else {
            $_SESSION[$success ? 'success' : 'error'] = $message;
            header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? '/'));
        }
        exit();
    }
}

// Controleer of gebruiker is ingelogd
if (!isset($_SESSION['user_id'])) {
    sendJsonResponse(false, 'Je moet ingelogd zijn om een reservering te maken', '/inloggen');
}

// Controleer of auto_id is ingevuld
if (empty($_POST['car_id'])) {
    sendJsonResponse(false, 'Geen auto geselecteerd');
}

$car_id = (int)$_POST['car_id'];
$user_id = $_SESSION['user_id'];
$start_date = date('Y-m-d');
$end_date = date('Y-m-d', strtotime('+1 day'));
$total_price = 0; // Geen prijsberekening meer

try {
    // Maak database verbinding
    $pdo = new PDO('mysql:host=localhost;dbname=project42;charset=utf8mb4', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Controleer of er al een actieve reservering is voor deze auto
    $stmt = $pdo->prepare("SELECT id FROM car_rentals WHERE user_id = ? AND car_id = ? AND status = 'bevestigd'");
    $stmt->execute([$user_id, $car_id]);
    
    if ($stmt->fetch()) {
        sendJsonResponse(false, 'Je hebt al een actieve reservering voor deze auto', '/mijn-account');
    }
    
    // Voeg een unieke constraint toe aan de database (eenmalig uitvoeren)
    try {
        $pdo->exec("ALTER TABLE car_rentals ADD CONSTRAINT unique_user_car_active UNIQUE (user_id, car_id, status)");
    } catch (PDOException $e) {
        // Constraint bestaat mogelijk al, negeer de fout
        if (strpos($e->getMessage(), 'Duplicate key name') === false) {
            error_log('Fout bij toevoegen constraint: ' . $e->getMessage());
        }
    }
    
    // Maak reservering
    $stmt = $pdo->prepare("
        INSERT INTO car_rentals 
        (user_id, car_id, start_date, end_date, total_price, status) 
        VALUES (?, ?, ?, ?, ?, 'bevestigd')
    ");
    
    $stmt->execute([
        $user_id,
        $car_id,
        $start_date,
        $end_date,
        $total_price
    ]);
    
    // Succesvol afgerond
    sendJsonResponse(true, 'Reservering succesvol geplaatst!', '/mijn-account');
    
} catch (Exception $e) {
    // Log de fout
    error_log('Fout bij reservering: ' . $e->getMessage());
    
    // Stuur foutmelding
    sendJsonResponse(false, 'Er is een fout opgetreden bij het plaatsen van je reservering');
}
