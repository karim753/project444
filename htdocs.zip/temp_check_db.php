<?php
// Database configuratie
$host = 'localhost';
$db = 'project42';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

// Maak verbinding met de database
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=$charset", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Bekijk de structuur van de car_rentals tabel
    $stmt = $pdo->query("SHOW COLUMNS FROM car_rentals");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h2>Structuur van de car_rentals tabel:</h2>";
    echo "<pre>";
    print_r($columns);
    echo "</pre>";
    
} catch (PDOException $e) {
    die("Database fout: " . $e->getMessage());
}
?>
