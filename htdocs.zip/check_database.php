<?php
// Database configuratie
$host = 'localhost';
$db = 'project42';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

// Maak verbinding met de database
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=$charset", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<h2>Database verbinding succesvol</h2>";
    
    // Controleer of de car_rentals tabel bestaat
    $tables = $pdo->query("SHOW TABLES LIKE 'car_rentals'")->fetchAll();
    
    if (empty($tables)) {
        echo "<div style='color: red;'>Let op: De 'car_rentals' tabel bestaat niet!</div>";
        echo "<h3>SQL om de tabel aan te maken:</h3>";
        echo "<pre>
CREATE TABLE `car_rentals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `car_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `price_per_day` decimal(10,2) NOT NULL,
  `rental_days` int(11) NOT NULL,
  `status` enum('bevestigd','geannuleerd','voltooid') NOT NULL DEFAULT 'bevestigd',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `car_id` (`car_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `car_rentals_ibfk_1` FOREIGN KEY (`car_id`) REFERENCES `cars` (`id`) ON DELETE CASCADE,
  CONSTRAINT `car_rentals_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        </pre>";
    } else {
        echo "<div style='color: green;'>De 'car_rentals' tabel bestaat.</div>";
    }
    
    // Controleer of de users tabel bestaat
    $tables = $pdo->query("SHOW TABLES LIKE 'users'")->fetchAll();
    if (empty($tables)) {
        echo "<div style='color: red;'>Let op: De 'users' tabel bestaat niet!</div>";
    } else {
        echo "<div style='color: green;'>De 'users' tabel bestaat.</div>";
    }
    
    // Controleer of de cars tabel bestaat
    $tables = $pdo->query("SHOW TABLES LIKE 'cars'")->fetchAll();
    if (empty($tables)) {
        echo "<div style='color: red;'>Let op: De 'cars' tabel bestaat niet!</div>";
    } else {
        echo "<div style='color: green;'>De 'cars' tabel bestaat.</div>";
    }
    
} catch (PDOException $e) {
    die("<div style='color: red;'>Database fout: " . $e->getMessage() . "</div>");
}
?>
