<?php
// Database configuratie
$host = 'localhost';
$db = 'project42';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

header('Content-Type: text/plain; charset=utf-8');

try {
    // Maak verbinding met de database
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=$charset", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "=== DATABASE VERBINDING GESLAAGD ===\n\n";
    
    // Controleer of de cars tabel bestaat
    $tables = $pdo->query("SHOW TABLES LIKE 'cars'")->fetchAll();
    
    if (empty($tables)) {
        echo "FOUT: De 'cars' tabel bestaat niet in de database '$db'\n";
        
        // Toon alle tabellen in de database
        echo "\nBestaande tabellen in database '$db':\n";
        $allTables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        if (empty($allTables)) {
            echo "Geen tabellen gevonden in de database!\n";
        } else {
            echo implode("\n", $allTables) . "\n";
        }
    } else {
        echo "SUCCES: De 'cars' tabel bestaat.\n";
        
        // Toon de structuur van de cars tabel
        echo "\nStructuur van de 'cars' tabel:\n";
        $columns = $pdo->query("DESCRIBE cars")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($columns as $column) {
            echo "- {$column['Field']} ({$column['Type']})\n";
        }
        
        // Toon het aantal rijen in de cars tabel
        $count = $pdo->query("SELECT COUNT(*) FROM cars")->fetchColumn();
        echo "\nAantal auto's in de database: " . $count . "\n";
        
        // Toon de eerste 3 auto's als voorbeeld
        if ($count > 0) {
            echo "\nEerste 3 auto's in de database:\n";
            $cars = $pdo->query("SELECT * FROM cars LIMIT 3")->fetchAll(PDO::FETCH_ASSOC);
            print_r($cars);
        }
    }
    
    // Controleer of de car_rentals tabel bestaat
    echo "\n\n=== CAR RENTALS TABEL ===\n";
    $tables = $pdo->query("SHOW TABLES LIKE 'car_rentals'")->fetchAll();
    
    if (empty($tables)) {
        echo "WAARSCHUWING: De 'car_rentals' tabel bestaat niet.\n";
    } else {
        echo "De 'car_rentals' tabel bestaat.\n";
        
        // Toon de structuur van de car_rentals tabel
        echo "\nStructuur van de 'car_rentals' tabel:\n";
        $columns = $pdo->query("DESCRIBE car_rentals")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($columns as $column) {
            echo "- {$column['Field']} ({$column['Type']})\n";
        }
    }
    
} catch (PDOException $e) {
    echo "FOUT: " . $e->getMessage() . "\n";
    
    // Probeer te verbinden zonder database om te controleren of de database bestaat
    try {
        $pdo = new PDO("mysql:host=$host", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Controleer of de database bestaat
        $stmt = $pdo->query("SHOW DATABASES LIKE '$db'");
        if ($stmt->rowCount() > 0) {
            echo "\nDe database '$db' bestaat, maar er is een probleem met de verbinding of de tabellen.\n";
        } else {
            echo "\nFOUT: De database '$db' bestaat niet!\n";
            echo "Bestaande databases:\n";
            $databases = $pdo->query("SHOW DATABASES")->fetchAll(PDO::FETCH_COLUMN);
            echo implode("\n", $databases) . "\n";
        }
    } catch (Exception $e) {
        echo "\nKan geen verbinding maken met de database server: " . $e->getMessage() . "\n";
    }
}
