<?php 
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../database/connection.php";
require_once __DIR__ . "/../includes/functions/cars.php";

// Haal het auto ID op uit de URL
$carId = $_GET['id'] ?? null;

if (!$carId) {
    header("Location: /pages/404.php");
    exit();
}

try {
    // Haal de auto op uit de database
    $car = getCarById($pdo, $carId);
    
    if (!$car) {
        header("Location: /pages/404.php");
        exit();
    }
    
    // Zorg dat de image path correct is
    $imagePath = !empty($car['image_url']) ? '/' . ltrim($car['image_url'], '/') : '/assets/images/placeholder-car.png';
    
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    header("Location: /pages/500.php");
    exit();
}
?>

<main class="car-detail">
    <div class="grid">
        <div class="row">
            <div class="advertorial">
                <h2><?= htmlspecialchars($car['brand'] . ' ' . $car['model']) ?></h2>
                <p><?= htmlspecialchars($car['description'] ?? '') ?></p>
                
                <div class="car-gallery">
                    <?php
                    // Controleer of de car_images tabel bestaat
                    $tableExists = $pdo->query("SHOW TABLES LIKE 'car_images'")->rowCount() > 0;
                    $images = [];
                    
                    if ($tableExists) {
                        try {
                            // Haal alle afbeeldingen voor deze auto op
                            $imagesStmt = $pdo->prepare("SELECT * FROM car_images WHERE car_id = ? ORDER BY is_primary DESC");
                            $imagesStmt->execute([$carId]);
                            $images = $imagesStmt->fetchAll();
                        } catch (PDOException $e) {
                            // Log de fout maar ga door met lege array
                            error_log("Fout bij ophalen afbeeldingen: " . $e->getMessage());
                        }
                    }
                    
                    // Toon de afbeeldingen of de standaardafbeelding als er geen zijn
                    if (empty($images)) {
                        echo '<div class="car-image">';
                        echo '<img src="' . htmlspecialchars($imagePath) . '" alt="' . htmlspecialchars($car['brand'] . ' ' . $car['model']) . '" onerror="this.src=\'/assets/images/placeholder-car.png\'">';
                        echo '</div>';
                    } else {
                        foreach ($images as $image) {
                            $imgPath = '/' . ltrim($image['image_url'], '/');
                            echo '<div class="car-image">';
                            echo '<img src="' . htmlspecialchars($imgPath) . '" alt="' . htmlspecialchars($car['brand'] . ' ' . $car['model']) . '" onerror="this.src=\'/assets/images/placeholder-car.png\'">';
                            echo '</div>';
                        }
                    }
                    ?>
                </div>
                <img src="/assets/images/header-circle-background.svg" alt="" class="background-header-element" onerror="this.src='/assets/images/placeholder-car.png'">
            </div>
        </div>
        <div class="row white-background">
            <h2><?= htmlspecialchars($car['brand'] . ' ' . $car['model']) ?></h2>
            <div class="car-actions">
                <div class="rating">
                    <span class="stars stars-4"></span>
                    <span>440+ reviewers</span>
                </div>
                <div class="like-container">
                    <button class="btn btn-outline-danger like-button" data-car-id="<?= htmlspecialchars($car['id']) ?>">
                        <i class="bi bi-heart"></i>
                        <span class="like-count ms-1"><?= getCarLikeCount($pdo, $car['id']) ?: 0 ?></span>
                    </button>
                </div>
            </div>
            <p><?= htmlspecialchars($car['description'] ?? 'Geen beschrijving beschikbaar') ?></p>
            
            <div class="car-specs-grid">
                <div class="spec-item">
                    <div class="spec-icon">
                        <img src="/assets/images/icons/car.svg" alt="Type" onerror="this.style.display='none'">
                    </div>
                    <div class="spec-details">
                        <div class="spec-label">Type</div>
                        <div class="spec-value"><?= htmlspecialchars($car['type'] ?? 'Niet gespecificeerd') ?></div>
                    </div>
                </div>
                
                <div class="spec-item">
                    <div class="spec-icon">
                        <img src="/assets/images/icons/profile-2user.svg" alt="Zitplaatsen" onerror="this.style.display='none'">
                    </div>
                    <div class="spec-details">
                        <div class="spec-label">Zitplaatsen</div>
                        <div class="spec-value"><?= htmlspecialchars($car['capacity'] ?? 'Niet gespecificeerd') ?></div>
                    </div>
                </div>
                
                <div class="spec-item">
                    <div class="spec-icon">
                        <img src="/assets/images/icons/car.svg" alt="Versnelling" onerror="this.style.display='none'">
                    </div>
                    <div class="spec-details">
                        <div class="spec-label">Versnelling</div>
                        <div class="spec-value"><?= htmlspecialchars($car['transmission'] ?? 'Niet gespecificeerd') ?></div>
                    </div>
                </div>
                
                <div class="spec-item">
                    <div class="spec-icon">
                        <img src="/assets/images/icons/gas-station.svg" alt="Brandstof" onerror="this.style.display='none'">
                    </div>
                    <div class="spec-details">
                        <div class="spec-label">Brandstof</div>
                        <div class="spec-value"><?= htmlspecialchars($car['fuel_capacity'] ?? 'Niet gespecificeerd') ?></div>
                    </div>
                </div>
            </div>
            <div class="call-to-action">
                <?php 
                // Zorg ervoor dat de prijs altijd correct wordt geformatteerd
                $price = isset($car['price']) ? (float)$car['price'] : 0;
                $formattedPrice = '€' . number_format($price, 2, ',', '.');
                
                // Controleer of er een originele prijs is die hoger is dan de huidige prijs
                $originalPrice = null;
                $formattedOriginalPrice = '';
                if (!empty($car['original_price']) && (float)$car['original_price'] > $price) {
                    $originalPrice = (float)$car['original_price'];
                    $formattedOriginalPrice = '€' . number_format($originalPrice, 2, ',', '.');
                }
                ?>
                <div class="row">
                    <span class="font-weight-bold">
                        <?= $formattedPrice ?>
                        <?php if ($formattedOriginalPrice): ?>
                            <span style="text-decoration: line-through; color: #999; margin-left: 5px;">
                                <?= $formattedOriginalPrice ?>
                            </span>
                        <?php endif; ?>
                    </span> / dag
                </div>
                <button type="button" id="huurNuKnop" class="button-primary" style="width: 100%; margin-bottom: 15px;">Huur nu</button>
                
                <!-- Modal Overlay -->
                <div id="reserveringModal" class="modal-overlay" style="display: none;">
                    <div class="modal-content">
                        <span class="close-modal">&times;</span>
                        <h3>Reserveren - <?= htmlspecialchars($car['brand'] . ' ' . $car['model']) ?></h3>
                        <form method="post" action="/actions/create_rental.php" class="reserveren-form" id="reserveringForm">
                            <input type="hidden" name="car_id" value="<?= htmlspecialchars($car['id']) ?>">
                            <input type="hidden" name="price_per_day" value="<?= htmlspecialchars($price) ?>">
                            <input type="hidden" name="total_price" id="total_price" value="">
                            
                            <div class="price-display" style="margin-bottom: 20px; padding: 15px; background-color: #f8f9fa; border-radius: 4px; text-align: center;">
                                <div style="font-size: 24px; font-weight: bold; color: #2c3e50;">
                                    <?= $formattedPrice ?>/dag
                                    <?php if ($formattedOriginalPrice): ?>
                                        <span style="font-size: 16px; color: #999; text-decoration: line-through; margin-left: 8px;">
                                            <?= $formattedOriginalPrice ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div id="totalPrice" style="margin-top: 10px; font-size: 18px; color: #27ae60; display: none;">
                                    Totaal: <span id="totalAmount">€0,00</span>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="start_date">Vanaf:</label>
                                <input type="date" 
                                       id="start_date" 
                                       name="start_date" 
                                       class="form-control"
                                       required 
                                       min="<?= date('Y-m-d') ?>">
                            </div>
                            
                            <div class="form-group">
                                <label for="end_date">Tot:</label>
                                <input type="date" 
                                       id="end_date" 
                                       name="end_date" 
                                       class="form-control"
                                       required 
                                       min="<?= date('Y-m-d', strtotime('+1 day')) ?>">
                            </div>
                            
                            <div class="form-actions">
                                <button type="button" class="button-secondary" id="annuleerKnop">Annuleren</button>
                                <button type="submit" class="button-primary">Bevestig reservering</button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <style>
                /* Modal Styling */
                .modal-overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    width: 100%;
                    height: 100%;
                    background-color: rgba(0, 0, 0, 0.7);
                    z-index: 1000;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    padding: 20px;
                    box-sizing: border-box;
                    overflow: auto;
                }
                
                .modal-content {
                    background: white;
                    padding: 30px;
                    border-radius: 8px;
                    width: 100%;
                    max-width: 500px;
                    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
                    max-height: 90vh;
                    overflow-y: auto;
                    position: relative;
                    margin: 0 auto;
                }
                
                .close-modal {
                    position: absolute;
                    top: 10px;
                    right: 15px;
                    font-size: 24px;
                    cursor: pointer;
                    color: #666;
                }
                
                .close-modal:hover {
                    color: #000;
                }
                
                .form-actions {
                    display: flex;
                    justify-content: flex-end;
                    gap: 10px;
                    margin-top: 20px;
                }
                
                .button-secondary {
                    padding: 10px 20px;
                    background-color: #f0f0f0;
                    color: #333;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                    cursor: pointer;
                    transition: all 0.3s ease;
                }
                
                .button-secondary:hover {
                    background-color: #e0e0e0;
                }
                </style>
                
                <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const modal = document.getElementById('reserveringModal');
                    const huurNuKnop = document.getElementById('huurNuKnop');
                    const closeModal = document.querySelector('.close-modal');
                    const annuleerKnop = document.getElementById('annuleerKnop');
                    const startDateInput = document.getElementById('start_date');
                    const endDateInput = document.getElementById('end_date');
                    const totalPriceElement = document.getElementById('totalPrice');
                    const totalAmountElement = document.getElementById('totalAmount');
                    const reserveringForm = document.getElementById('reserveringForm');
                    const pricePerDay = <?= $price ?>; // Prijs per dag uit PHP
                    
                    // Open modal
                    huurNuKnop.addEventListener('click', function() {
                        modal.style.display = 'block';
                        document.body.style.overflow = 'hidden'; // Voorkom scrollen
                    });
                    
                    // Sluit modal
                    function closeModalFunc() {
                        modal.style.display = 'none';
                        document.body.style.overflow = ''; // Herstel scrollen
                    }
                    
                    // Sluit knoppen
                    if (closeModal) closeModal.addEventListener('click', closeModalFunc);
                    if (annuleerKnop) annuleerKnop.addEventListener('click', closeModalFunc);
                    
                    // Sluit bij klik buiten de modal
                    window.addEventListener('click', function(event) {
                        if (event.target === modal) {
                            closeModalFunc();
                        }
                    });
                    
                    // Voorkom dat de modal sluit bij klikken in het formulier
                    document.querySelector('.modal-content').addEventListener('click', function(e) {
                        e.stopPropagation();
                    });
                    
                    // Bereken totaalprijs bij wijziging van datums
                    function calculateTotalPrice() {
                        if (!startDateInput.value || !endDateInput.value) {
                            totalPriceElement.style.display = 'none';
                            return 0;
                        }
                        
                        const startDate = new Date(startDateInput.value);
                        const endDate = new Date(endDateInput.value);
                        
                        // Bereken het aantal dagen
                        const timeDiff = endDate - startDate;
                        const daysDiff = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));
                        
                        if (daysDiff <= 0) {
                            totalPriceElement.style.display = 'none';
                            return 0;
                        }
                        
                        // Bereken totaalprijs
                        const totalPrice = daysDiff * pricePerDay;
                        
                        // Update de UI en het verborgen veld
                        totalAmountElement.textContent = '€' + totalPrice.toFixed(2).replace('.', ',');
                        document.getElementById('total_price').value = totalPrice.toFixed(2);
                        totalPriceElement.style.display = 'block';
                        
                        return totalPrice;
                    }
                    
                    // Voeg event listeners toe voor datumvelden
                    startDateInput.addEventListener('change', calculateTotalPrice);
                    endDateInput.addEventListener('change', calculateTotalPrice);
                    
                    // Verstuur formulier via AJAX
                    reserveringForm.addEventListener('submit', function(e) {
                        e.preventDefault();
                        
                        // Bereken totaalprijs
                        const totalPrice = calculateTotalPrice();
                        if (totalPrice <= 0) {
                            alert('Selecteer geldige datums');
                            return;
                        }
                        
                        // Verzamel formuliergegevens
                        const formData = new FormData(this);
                        // Het total_price veld is al ingesteld in het formulier
                        
                        // Toon laadstatus
                        const submitButton = this.querySelector('button[type="submit"]');
                        const originalButtonText = submitButton.innerHTML;
                        submitButton.disabled = true;
                        submitButton.innerHTML = 'Bezig met verwerken...';
                        
                        // Verstuur het formulier
                        fetch(this.action, {
                            method: 'POST',
                            body: formData,
                            headers: {
                                'X-Requested-With': 'XMLHttpRequest'
                            }
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                // Toon succesbericht en doorsturen
                                if (data.redirect) {
                                    window.location.href = data.redirect;
                                } else {
                                    window.location.href = '/mijn-account';
                                }
                            } else {
                                // Toon foutmelding
                                alert(data.message || 'Er is een fout opgetreden bij het verwerken van je reservering.');
                                submitButton.disabled = false;
                                submitButton.innerHTML = originalButtonText;
                            }
                        })
                        .catch(error => {
                            console.error('Fout:', error);
                            alert('Er is een fout opgetreden bij het versturen van het formulier.');
                            submitButton.disabled = false;
                            submitButton.innerHTML = originalButtonText;
                        });
                    });
                });
                </script>
                <script src="/includes/js/car-detail.js"></script>
            </div>
        </div>
    </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php" ?>

<style>
/* Car gallery styles */
.car-gallery {
    display: flex;
    gap: 1.5rem;
    overflow-x: auto;
    padding: 1.5rem 1rem;
    scrollbar-width: thin;
    scrollbar-color: rgba(0,0,0,0.1) transparent;
    margin: 1rem -1rem;
    box-sizing: border-box;
    background: transparent;
    border-radius: 0;
}

.car-gallery::-webkit-scrollbar {
    height: 4px;
}

.car-gallery::-webkit-scrollbar-track {
    background: transparent;
    margin: 0 1rem;
}

.car-gallery::-webkit-scrollbar-thumb {
    background: rgba(0,0,0,0.1);
    border-radius: 2px;
}

.car-gallery::-webkit-scrollbar-thumb:hover {
    background: rgba(0,0,0,0.2);
}

.car-image {
    flex: 0 0 auto;
    max-height: 60vh;
    max-width: 90vw;
    border-radius: 10px;
    overflow: hidden;
    background: transparent;
    box-shadow: none;
    transition: transform 0.2s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0;
}

.car-image:hover {
    transform: translateY(-2px) scale(1.02);
}

.car-image img {
    max-height: 100%;
    max-width: 100%;
    height: auto;
    width: auto;
    object-fit: contain;
    display: block;
    border-radius: 6px;
}

/* Responsive adjustments */
@media (max-width: 992px) {
    .car-image {
        max-height: 55vh;
    }
}

@media (max-width: 768px) {
    .car-gallery {
        padding: 1rem 0.75rem;
        gap: 1.25rem;
    }
    
    .car-image {
        max-height: 50vh;
        min-width: 85%;
    }
}

@media (max-width: 480px) {
    .car-gallery {
        padding: 0.75rem 0.5rem;
        gap: 1rem;
        margin: 0.5rem -0.5rem;
    }
    
    .car-image {
        max-height: 45vh;
        min-width: 85%;
    }
}

/* Modal Styling */
.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.7);
    overflow-y: auto;
}

.modal-content {
    background-color: #fff;
    margin: 5% auto;
    padding: 2rem;
    border-radius: 8px;
    max-width: 500px;
    width: 90%;
    position: relative;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
}

.close-modal {
    position: absolute;
    right: 1.5rem;
    top: 1rem;
    font-size: 2rem;
    font-weight: bold;
    cursor: pointer;
    color: #666;
}

.close-modal:hover {
    color: #000;
}

/* Form Styling */
.reserveren-form {
    margin-top: 1.5rem;
}

.form-group {
    margin-bottom: 1.5rem;
}

.form-group label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
    color: #333;
}

.form-group input[type="date"] {
    width: 100%;
    padding: 0.75rem;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 1rem;
}

.form-group input[type="date"]:focus {
    border-color: #4a90e2;
    outline: none;
    box-shadow: 0 0 0 2px rgba(74, 144, 226, 0.2);
}

.price-summary {
    background-color: #f9f9f9;
    border-radius: 4px;
    padding: 1rem;
    margin: 1.5rem 0;
}

.price-row {
    display: flex;
    justify-content: space-between;
    margin-bottom: 0.5rem;
}

.price-row.total {
    margin-top: 1rem;
    padding-top: 0.75rem;
    border-top: 1px solid #ddd;
    font-size: 1.1rem;
}

.alert {
    padding: 0.75rem 1rem;
    margin-bottom: 1.5rem;
    border-radius: 4px;
    font-size: 0.9rem;
}

.alert-error {
    background-color: #ffebee;
    color: #c62828;
    border: 1px solid #ffcdd2;
}

.alert-success {
    background-color: #e8f5e9;
    color: #2e7d32;
    border: 1px solid #c8e6c9;
}

/* Responsive aanpassingen */
@media (max-width: 600px) {
    .modal-content {
        margin: 10% auto;
        padding: 1.5rem;
    }
    
    .price-row {
        font-size: 0.9rem;
    }
    
    .price-row.total {
        font-size: 1rem;
    }
}
</style>
