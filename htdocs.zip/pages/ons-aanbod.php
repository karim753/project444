<?php require_once __DIR__ . "/../includes/header.php" ?>

<main>
    <h2>Ons aanbod</h2>
</main>
<?php require_once __DIR__ . "/../includes/footer.php" ?>

