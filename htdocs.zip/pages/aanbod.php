<?php 
require __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../database/connection.php";
require_once __DIR__ . "/../includes/functions/cars.php";

// Add some CSS for the filter section
?>
<style>
/* Filter Section Styles */
.filter-section {
    background: #f8f9fa;
    padding: 20px;
    border-radius: 8px;
    margin-bottom: 30px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.filter-form {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
    align-items: flex-end;
}

.filter-group {
    flex: 1;
    min-width: 180px;
}

.filter-group label {
    display: block;
    margin-bottom: 5px;
    font-size: 14px;
    color: #495057;
    font-weight: 500;
}

.filter-group select,
.filter-group input[type="number"] {
    width: 100%;
    padding: 10px 12px;
    border: 1px solid #ced4da;
    border-radius: 4px;
    font-size: 14px;
    background-color: #fff;
}

.filter-buttons {
    display: flex;
    gap: 10px;
    margin-top: 5px;
}

.button-primary {
    background: #4a90e2;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    text-decoration: none;
    display: inline-block;
}

.button-secondary {
    background: #6c757d;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    text-decoration: none;
    display: inline-block;
}

.button-primary:hover {
    background: #3a7bc8;
}

.button-secondary:hover {
    background: #5a6268;
}

.filter-results {
    margin-bottom: 20px;
    font-size: 15px;
    color: #495057;
}

.no-results {
    text-align: center;
    padding: 30px;
    background: #f8f9fa;
    border-radius: 8px;
    grid-column: 1 / -1;
}

.no-results a {
    color: #4a90e2;
    text-decoration: none;
}

.no-results a:hover {
    text-decoration: underline;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .filter-form {
        flex-direction: column;
    }
    
    .filter-group {
        width: 100%;
    }
    
    .filter-buttons {
        width: 100%;
        justify-content: space-between;
    }
    
    .button-primary,
    .button-secondary {
        flex: 1;
        text-align: center;
    }
}
</style>

<?php

try {
    // Haal alle auto's op uit de database
    $allCars = getAllCars($pdo);
    
} catch (PDOException $e) {
    error_log("Database fout: " . $e->getMessage());
    $allCars = [];
    $error = "Er is een fout opgetreden bij het ophalen van de auto's. Probeer het later opnieuw.";
}
?>

<main class="main-content">
    <div class="container">
        <h1 class="section-title">Ons volledige aanbod</h1>
        
        <!-- Filter Section -->
        <div class="filter-section">
            <form method="get" class="filter-form">
                <div class="filter-group">
                    <label for="brand">Merk</label>
                    <select name="brand" id="brand">
                        <option value="">Alle merken</option>
                        <?php
                        $brands = [];
                        foreach ($allCars as $car) {
                            if (!empty($car['brand']) && !in_array($car['brand'], $brands)) {
                                $brands[] = $car['brand'];
                                $selected = (isset($_GET['brand']) && $_GET['brand'] === $car['brand']) ? 'selected' : '';
                                echo "<option value='" . htmlspecialchars($car['brand']) . "' $selected>" . htmlspecialchars($car['brand']) . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label for="fuel_type">Brandstof</label>
                    <select name="fuel_type" id="fuel_type">
                        <option value="">Alle typen</option>
                        <?php
                        $fuelTypes = [];
                        foreach ($allCars as $car) {
                            if (!empty($car['fuel_type']) && !in_array($car['fuel_type'], $fuelTypes)) {
                                $fuelTypes[] = $car['fuel_type'];
                                $selected = (isset($_GET['fuel_type']) && $_GET['fuel_type'] === $car['fuel_type']) ? 'selected' : '';
                                echo "<option value='" . htmlspecialchars($car['fuel_type']) . "' $selected>" . htmlspecialchars($car['fuel_type']) . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label for="transmission">Versnelling</label>
                    <select name="transmission" id="transmission">
                        <option value="">Alle typen</option>
                        <?php
                        $transmissions = [];
                        foreach ($allCars as $car) {
                            if (!empty($car['transmission']) && !in_array($car['transmission'], $transmissions)) {
                                $transmissions[] = $car['transmission'];
                                $selected = (isset($_GET['transmission']) && $_GET['transmission'] === $car['transmission']) ? 'selected' : '';
                                echo "<option value='" . htmlspecialchars($car['transmission']) . "' $selected>" . htmlspecialchars($car['transmission']) . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label for="price_max">Max prijs per dag</label>
                    <input type="number" id="price_max" name="price_max" min="0" 
                           value="<?= htmlspecialchars($_GET['price_max'] ?? '') ?>" 
                           placeholder="€ max">
                </div>
                
                <div class="filter-buttons">
                    <button type="submit" class="button-primary">Filter toepassen</button>
                    <a href="/aanbod" class="button-secondary">Reset filters</a>
                </div>
            </form>
        </div>
        
        <?php
        // Apply filters
        $filteredCars = $allCars;
        
        if (!empty($_GET['brand'])) {
            $filteredCars = array_filter($filteredCars, function($car) {
                return isset($car['brand']) && $car['brand'] === $_GET['brand'];
            });
        }
        
        if (!empty($_GET['fuel_type'])) {
            $filteredCars = array_filter($filteredCars, function($car) {
                return isset($car['fuel_type']) && $car['fuel_type'] === $_GET['fuel_type'];
            });
        }
        
        if (!empty($_GET['transmission'])) {
            $filteredCars = array_filter($filteredCars, function($car) {
                return isset($car['transmission']) && $car['transmission'] === $_GET['transmission'];
            });
        }
        
        if (!empty($_GET['price_max'])) {
            $maxPrice = (float)$_GET['price_max'];
            $filteredCars = array_filter($filteredCars, function($car) use ($maxPrice) {
                return isset($car['price']) && (float)$car['price'] <= $maxPrice;
            });
        }
        
        // Re-index array after filtering and update allCars
        $filteredCars = array_values($filteredCars);
        $allCars = $filteredCars;
        ?>
        
        <div class="filter-results">
            <p><?= count($filteredCars) ?> auto's gevonden</p>
        </div>
        
        <div class="cars">
        <?php if (empty($filteredCars)): ?>
    <p>Geen auto's</p>
<?php else: ?>
    <?php foreach ($filteredCars as $car): ?>
                    <div class="car-details">
                        <div class="car-brand">
                            <h3><?= htmlspecialchars($car['brand'] ?? 'Onbekend merk') ?></h3>
                            <div class="car-type">
                                <?= htmlspecialchars($car['model'] ?? 'Onbekend model') ?>
                            </div>
                        </div>
                        <?php 
                        // Get image path from database or use placeholder
                        $imagePath = !empty($car['image_url']) ? trim($car['image_url']) : 'assets/images/placeholder-car.png';
                        $altText = htmlspecialchars(($car['brand'] ?? 'Auto') . ' ' . ($car['model'] ?? ''));
                        
                        // Clean up the path
                        $imagePath = str_replace('\\', '/', $imagePath); // Convert Windows paths
                        $imagePath = ltrim($imagePath, '/'); // Remove leading slashes
                        
                        // If the path doesn't exist, use placeholder
                        $fullPath = $_SERVER['DOCUMENT_ROOT'] . '/' . $imagePath;
                        if (!file_exists($fullPath)) {
                            $imagePath = 'assets/images/placeholder-car.png';
                        }
                        ?>
                        <div style="height: 200px; display: flex; align-items: center; justify-content: center; background: #f5f5f5; padding: 10px;">
                            <img src="/<?= htmlspecialchars($imagePath) ?>" 
                                 alt="<?= $altText ?>" 
                                 onerror="this.src='/assets/images/placeholder-car.png'" 
                                 style="max-width: 100%; max-height: 100%; object-fit: contain;">
                        </div>
                        <div class="car-specification">
                            <?php if (isset($car['fuel_type'])): ?>
                                <div class="spec-item">
                                    <img src="/assets/images/icons/gas-station.svg" alt="Brandstof" class="spec-icon" onerror="this.style.display='none'">
                                    <span class="spec-text"><?= htmlspecialchars($car['fuel_type']) ?></span>
                                </div>
                            <?php endif; ?>
                            <?php if (isset($car['transmission'])): ?>
                                <div class="spec-item">
                                    <img src="/assets/images/icons/car.svg" alt="Versnelling" class="spec-icon" onerror="this.style.display='none'">
                                    <span class="spec-text"><?= htmlspecialchars($car['transmission']) ?></span>
                                </div>
                            <?php endif; ?>
                            <?php if (isset($car['fuel_capacity'])): ?>
                                <div class="spec-item">
                                    <img src="/assets/images/icons/setting.svg" alt="Motorinhoud" class="spec-icon" onerror="this.style.display='none'">
                                    <span class="spec-text"><?= htmlspecialchars($car['fuel_capacity']) ?>L</span>
                                </div>
                            <?php endif; ?>
                            <?php if (isset($car['seats'])): ?>
                                <div class="spec-item">
                                    <img src="/assets/images/icons/profile-2user.svg" alt="Zitplaatsen" class="spec-icon" onerror="this.style.display='none'">
                                    <span class="spec-text"><?= htmlspecialchars($car['seats']) ?> zit</span>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php if (isset($car['year'])): ?>
                            <div class="car-year">
                                <img src="/assets/images/icons/calendar.svg" alt="Bouwjaar" class="year-icon" onerror="this.style.display='none'">
                                <span><?= htmlspecialchars($car['year']) ?></span>
                            </div>
                        <?php endif; ?>
                        <div class="rent-details">
                            <?php if (isset($car['price'])): ?>
                                <span><span class="font-weight-bold">€<?= number_format((float)$car['price'], 2, ',', '.') ?></span> / dag</span>
                            <?php else: ?>
                                <span><span class="font-weight-bold">€0,00</span> / dag</span>
                            <?php endif; ?>
                            <a href="/car-detail?id=<?= $car['id'] ?? '' ?>" class="button-primary">Bekijk nu</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
    </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>
