<?php 
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../database/connection.php";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_after_login'] = '/mijn-account';
    header('Location: /pages/login-form.php');
    exit();
}

try {
    // Get user details
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();

    // Get user's rentals with car details and calculate total price
    $rentalsStmt = $pdo->prepare("
        SELECT 
            cr.*, 
            c.brand, 
            c.model, 
            c.image_url,
            c.price as daily_price,
            (DATEDIFF(cr.end_date, cr.start_date) + 1) as rental_days,
            (c.price * (DATEDIFF(cr.end_date, cr.start_date) + 1)) as total_price
        FROM car_rentals cr
        JOIN cars c ON cr.car_id = c.id
        WHERE cr.user_id = ?
        ORDER BY cr.start_date DESC
    ");
    $rentalsStmt->execute([$_SESSION['user_id']]);
    $rentals = $rentalsStmt->fetchAll();

    // Debug output om de verhuurgegevens te controleren
    error_log("Aantal verhuringen: " . count($rentals));
    foreach ($rentals as $i => $rental) {
        error_log("Verhuuring #" . ($i+1) . ":");
        error_log("- ID: " . ($rental['id'] ?? 'onbekend'));
        error_log("- Status: " . ($rental['status'] ?? 'onbekend'));
        error_log("- Totaal prijs: " . ($rental['total_price'] ?? 'onbekend'));
        error_log("- Totaal prijs calc: " . ($rental['total_price_calc'] ?? 'onbekend'));
        error_log("- Start datum: " . ($rental['start_date'] ?? 'onbekend'));
        error_log("- Eind datum: " . ($rental['end_date'] ?? 'onbekend'));
    }

    // Calculate total days for each rental
    foreach ($rentals as &$rental) {
        $start = new DateTime($rental['start_date']);
        $end = new DateTime($rental['end_date']);
        $days = $start->diff($end)->days + 1; // +1 to include both start and end day
        $rental['total_days'] = $days;
        $rental['total_price_calc'] = $rental['total_price']; // Gebruik de opgeslagen totaalprijs
    }
    unset($rental); // Unset reference

    // Debug info (alleen voor ontwikkelingsdoeleinden)
    $debugOutput = '';
    if (isset($_GET['debug'])) {
        $debugInfo = [
            'user_id' => $_SESSION['user_id'],
            'message' => 'Like functionaliteit is actief maar wordt niet getoond in de gebruikersinterface'
        ];
        $debugOutput = '<div class="alert alert-info">';
        $debugOutput .= '<h4>Debug Informatie</h4>';
        $debugOutput .= '<pre>' . htmlspecialchars(print_r($debugInfo, true)) . '</pre>';
        $debugOutput .= '</div>';
    }

} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $error = "Er is een fout opgetreden bij het ophalen van je gegevens.";
}
?>

<main class="account-page">
    <div class="container">
        <?php if (isset($debugOutput)) echo $debugOutput; ?>
        <h1>Mijn Account</h1>
        
        <div class="account-grid">
            <!-- User Info -->
            <div class="account-section">
                <h2>Mijn gegevens</h2>
                <div class="user-info">
                    <div class="info-row">
                        <span class="label">E-mail:</span>
                        <span class="value"><?= htmlspecialchars($user['email']) ?></span>
                    </div>
                </div>
            </div>

            <!-- Rentals -->
            <div class="account-section">
                <h2>Mijn verhuringen</h2>
                <?php if (empty($rentals)): ?>
                    <p>Je hebt nog geen auto's gehuurd.</p>
                    <a href="/aanbod" class="button-primary">Bekijk ons aanbod</a>
                <?php else: 
                    // Bereken bedragen
                    $totaalBedrag = 0;
                    $betaaldBedrag = 0;
                    $openstaandBedrag = 0;
                    
                    // Bereken betaald en openstaand bedrag op basis van status
                    foreach ($rentals as $rental) {
                        // Bereken de totaalprijs op basis van dagprijs * aantal dagen
                        $dagen = (new DateTime($rental['end_date']))->diff(new DateTime($rental['start_date']))->days + 1;
                        $prijs = ($rental['daily_price'] ?? 0) * $dagen;
                        $totaalBedrag += $prijs;
                        
                        if (in_array($rental['status'] ?? '', ['confirmed', 'completed'])) {
                            $betaaldBedrag += $prijs;
                        } else {
                            $openstaandBedrag += $prijs;
                        }
                    }
                    ?>
                    <div class="totaal-bedrag" style="margin-bottom: 20px; padding: 15px; background: #f8f9fa; border-radius: 8px; border-left: 4px solid #4a90e2;">
                        <div style="display: flex; justify-content: space-between; flex-wrap: wrap; gap: 20px;">
                            <div>
                                <h3 style="margin: 0 0 5px 0; color: #333; font-size: 1rem;">Totaal besteed</h3>
                                <p style="font-size: 1.5rem; font-weight: bold; margin: 0; color: #2c3e50;">
                                    €<?= number_format($betaaldBedrag, 2, ',', '.') ?>
                                </p>
                            </div>
                            <div>
                                <h3 style="margin: 0 0 5px 0; color: #333; font-size: 1rem;">Nog te betalen</h3>
                                <p style="font-size: 1.5rem; font-weight: bold; margin: 0; color: #e74c3c;">
                                    €<?= number_format($openstaandBedrag, 2, ',', '.') ?>
                                </p>
                            </div>
                            <div>
                                <h3 style="margin: 0 0 5px 0; color: #333; font-size: 1rem;">Totaal</h3>
                                <p style="font-size: 1.5rem; font-weight: bold; margin: 0; color: #27ae60;">
                                    €<?= number_format($totaalBedrag, 2, ',', '.') ?>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="rentals-list">
                        <?php foreach ($rentals as $rental): ?>
                            <div class="rental-card">
                                <div class="rental-image">
                                    <img src="<?= !empty($rental['image_url']) ? '/' . ltrim($rental['image_url'], '/') : '/assets/images/placeholder-car.png' ?>" 
                                         alt="<?= htmlspecialchars($rental['brand'] . ' ' . $rental['model']) ?>">
                                </div>
                                <div class="rental-details">
                                    <h3><?= htmlspecialchars($rental['brand'] . ' ' . $rental['model']) ?></h3>
                                    <div class="rental-dates">
                                        <span class="date">
                                            <i class="far fa-calendar"></i>
                                            <?= date('d-m-Y', strtotime($rental['start_date'])) ?> - 
                                            <?= date('d-m-Y', strtotime($rental['end_date'])) ?>
                                        </span>
                                        <span class="days">(<?= $rental['total_days'] ?> dagen)</span>
                                    </div>
                                    <div class="rental-price">
                                        <span class="amount">€<?= number_format($rental['total_price_calc'], 2, ',', '.') ?></span>
                                        <span class="status status-<?= $rental['status'] ?>">
                                            <?php 
                                            $statusLabels = [
                                                'pending' => 'In behandeling',
                                                'confirmed' => 'Bevestigd',
                                                'completed' => 'Voltooid',
                                                'cancelled' => 'Geannuleerd'
                                            ];
                                            echo $statusLabels[$rental['status']] ?? ucfirst($rental['status']);
                                            ?>
                                        </span>
                                    </div>
                                </div>
                                <div class="rental-actions">
                                    <button class="button-cancel cancel-rental-btn" data-rental-id="<?= $rental['id'] ?>">Annuleren</button>
                                    <a href="/pages/car-detail.php?id=<?= $rental['car_id'] ?>" class="button-secondary">Bekijk auto</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</main>

<style>
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 1.5rem;
    margin-top: 1rem;
}

.car-card {
    background: white;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    transition: transform 0.2s, box-shadow 0.2s;
}

.car-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 6px 16px rgba(0,0,0,0.12);
}

.car-image {
    position: relative;
    height: 180px;
    overflow: hidden;
}

.car-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s;
}

.car-card:hover .car-image img {
    transform: scale(1.05);
}

.like-button {
    position: absolute;
    top: 10px;
    right: 10px;
    background: white;
    width: 36px;
    height: 36px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(0,0,0,0.15);
    transition: all 0.2s;
}

.like-button:hover {
    transform: scale(1.1);
}

.like-button.liked {
    color: #dc3545;
}

.car-details {
    padding: 1.25rem;
}

.car-details h3 {
    margin: 0 0 0.5rem;
    font-size: 1.1rem;
    color: #333;
}

.car-specs {
    display: flex;
    flex-wrap: wrap;
    gap: 0.75rem;
    margin: 0.75rem 0;
    color: #666;
    font-size: 0.9rem;
}

.car-specs i {
    margin-right: 4px;
    color: #6c757d;
}

.car-price {
    display: flex;
    align-items: baseline;
    margin: 1rem 0;
}

.car-price .price {
    font-size: 1.25rem;
    font-weight: 600;
    color: #333;
}

.car-price .period {
    margin-left: 0.5rem;
    color: #6c757d;
    font-size: 0.9rem;
}

.account-page {
    padding: 2rem 0;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 1rem;
}

h1 {
    font-size: 2rem;
    margin-bottom: 2rem;
    color: #333;
}

.account-grid {
    display: grid;
    grid-template-columns: 300px 1fr;
    gap: 2rem;
}

.account-section {
    background: white;
    border-radius: 8px;
    padding: 1.5rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.account-section h2 {
    font-size: 1.25rem;
    margin-top: 0;
    margin-bottom: 1.5rem;
    padding-bottom: 0.75rem;
    border-bottom: 1px solid #eee;
}

.user-info {
    margin-bottom: 1.5rem;
}

.info-row {
    display: flex;
    justify-content: space-between;
    margin-bottom: 0.75rem;
    padding-bottom: 0.75rem;
    border-bottom: 1px solid #f5f5f5;
}

.info-row:last-child {
    border-bottom: none;
    margin-bottom: 0;
    padding-bottom: 0;
}

.label {
    font-weight: 600;
    color: #666;
}

.rentals-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.rental-card {
    display: flex;
    border: 1px solid #eee;
    border-radius: 8px;
    overflow: hidden;
    transition: transform 0.2s, box-shadow 0.2s;
}

.rental-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.rental-image {
    width: 200px;
    flex-shrink: 0;
}

.rental-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.rental-details {
    flex: 1;
    padding: 1rem;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

.rental-details h3 {
    margin: 0 0 0.5rem 0;
    font-size: 1.1rem;
}

.rental-dates {
    color: #666;
    font-size: 0.9rem;
    margin-bottom: 0.5rem;
}

.rental-dates .date {
    margin-right: 0.5rem;
}

.rental-dates .days {
    color: #888;
}

.rental-price {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 0.5rem;
}

.rental-price .amount {
    font-size: 1.2rem;
    font-weight: 600;
    color: #333;
}

.status {
    padding: 0.25rem 0.5rem;
    border-radius: 4px;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: capitalize;
}

.status-pending {
    background-color: #fff3cd;
    color: #856404;
}

.status-confirmed {
    background-color: #d4edda;
    color: #155724;
}

.status-completed {
    background-color: #e2e3e5;
    color: #383d41;
}

.status-cancelled {
    background-color: #f8d7da;
    color: #721c24;
}

.rental-actions {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
    padding: 1rem;
    border-left: 1px solid #eee;
    justify-content: center;
}

.button-secondary {
    display: inline-block;
    padding: 0.5rem 1rem;
    background: white;
    color: #333;
    border: 1px solid #ddd;
    border-radius: 4px;
    text-align: center;
    text-decoration: none;
    cursor: pointer;
    transition: all 0.2s;
}

.button-secondary:hover {
    background: #f5f5f5;
    border-color: #ccc;
}

.button-cancel {
    padding: 0.5rem 1rem;
    background: #fff3f3;
    color: #dc3545;
    border: 1px solid #f5c6cb;
    border-radius: 4px;
    cursor: pointer;
    transition: all 0.2s;
}

.button-cancel:hover {
    background: #f8d7da;
    border-color: #f1b0b7;
}

/* Responsive */
@media (max-width: 992px) {
    .account-grid {
        grid-template-columns: 1fr;
    }
    
    .rental-card {
        flex-direction: column;
    }
    
    .rental-image {
        width: 100%;
        height: 200px;
    }
    
    .rental-actions {
        flex-direction: row;
        border-left: none;
        border-top: 1px solid #eee;
        justify-content: flex-start;
    }
}
</style>

<script src="/includes/js/car-detail.js"></script>

<script>
// Functie om de like-knop bij te werken
function updateLikeButton(button, isLiked, likeCount) {
    const icon = button.querySelector('i');
    const countElement = button.querySelector('.like-count');
    
    if (isLiked) {
        button.classList.add('liked');
        icon.classList.remove('bi-heart');
        icon.classList.add('bi-heart-fill');
    } else {
        button.classList.remove('liked');
        icon.classList.remove('bi-heart-fill');
        icon.classList.add('bi-heart');
    }
    
    if (countElement) {
        countElement.textContent = likeCount > 0 ? likeCount : '';
    }
}

// Like-knop functionaliteit
function setupLikeButton(button) {
    const carId = button.dataset.carId;
    if (!carId) return;
    
    // Voeg event listener toe voor klikken
    button.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        
        // Voorkom dubbele klikken
        if (button.classList.contains('loading')) return;
        button.classList.add('loading');
        
        const formData = new FormData();
        formData.append('car_id', carId);
        
        fetch('/actions/toggle-car-like.php', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                updateLikeButton(button, data.action === 'liked', data.like_count);
                
                // Verwijder de kaart als we niet langer van de auto houden
                if (data.action === 'unliked') {
                    const card = button.closest('.car-card');
                    if (card) {
                        card.style.opacity = '0';
                        setTimeout(() => card.remove(), 300);
                    }
                }
            } else {
                throw new Error(data.message || 'Er is een fout opgetreden');
            }
        })
        .catch(error => {
            console.error('Fout bij liken:', error);
            alert('Fout: ' + (error.message || 'Kon de like niet verwerken'));
        })
        .finally(() => {
            button.classList.remove('loading');
        });
    });
}

// Initialiseer like knoppen wanneer de pagina laadt
document.addEventListener('DOMContentLoaded', function() {
    // Initialize like buttons
    document.querySelectorAll('.like-button').forEach(button => {
        setupLikeButton(button);
    });
    
    // Initialize delete rental buttons
    document.querySelectorAll('.cancel-rental-btn').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const rentalCard = this.closest('.rental-card');
            
            if (!confirm('Weet u zeker dat u deze reservering wilt verwijderen?')) {
                return;
            }
            
            // Show loading state
            const originalText = this.textContent;
            this.disabled = true;
            this.textContent = 'Verwijderen...';
            
            // Send delete request
            const formData = new FormData();
            formData.append('rental_id', this.getAttribute('data-rental-id'));
            
            fetch('/actions/cancel_rental.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data && data.success) {
                    // Remove the rental card from the page
                    rentalCard.remove();
                    alert('Reservering is verwijderd');
                } else {
                    throw new Error(data && data.message || 'Kon de reservering niet verwijderen');
                }
            })
            .catch(error => {
                console.error('Fout bij verwijderen reservering:', error);
                alert('Fout: ' + (error.message || 'Kon de reservering niet verwijderen'));
                this.disabled = false;
                this.textContent = originalText;
            });
        });
    });
});
</script>

<?php require_once __DIR__ . "/../includes/footer.php" ?>
