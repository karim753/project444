<?php 
// Foutrapportage aanzetten
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../database/connection.php";
require_once __DIR__ . "/../includes/functions/cars.php";

try {
    // Haal alle auto's op uit de database
    $cars = getAllCars($pdo);
    
    // Neem de eerste 4 auto's als populaire auto's
    $popularCars = array_slice($cars, 0, 4);
    
} catch (PDOException $e) {
    error_log("Database fout: " . $e->getMessage());
    $popularCars = [];
    $error = "Er is een fout opgetreden bij het ophalen van de auto's. Probeer het later opnieuw.";
}
?>

<main class="main-content">
    <div class="container">
        <h1 class="section-title">Populaire auto's</h1>
        <div class="cars">
            <?php if (empty($popularCars)): ?>
                <p>Er zijn momenteel geen auto's beschikbaar.</p>
            <?php else: ?>
                <?php foreach ($popularCars as $car): ?>
                    <div class="car-details">
                        <div class="car-brand">
                            <h3><?= htmlspecialchars($car['brand'] ?? 'Onbekend merk') ?></h3>
                            <div class="car-type">
                                <?= htmlspecialchars($car['model'] ?? 'Onbekend model') ?>
                            </div>
                        </div>
                        <?php 
                        // Get image path from database or use placeholder
                        $imagePath = !empty($car['image_url']) ? trim($car['image_url']) : 'assets/images/placeholder-car.png';
                        $altText = htmlspecialchars(($car['brand'] ?? 'Auto') . ' ' . ($car['model'] ?? ''));
                        
                        // Clean up the path
                        $imagePath = str_replace('\\', '/', $imagePath); // Convert Windows paths
                        $imagePath = ltrim($imagePath, '/'); // Remove leading slashes
                        
                        // If the path doesn't exist, use placeholder
                        $fullPath = $_SERVER['DOCUMENT_ROOT'] . '/' . $imagePath;
                        if (!file_exists($fullPath)) {
                            $imagePath = 'assets/images/placeholder-car.png';
                        }
                        ?>
                        <img src="/<?= htmlspecialchars($imagePath) ?>" 
                             alt="<?= $altText ?>" 
                             onerror="this.src='/assets/images/placeholder-car.png'" 
                             style="width: 100%; height: 200px; object-fit: cover;">
                        <div class="car-specification">
                            <?php if (isset($car['fuel_type'])): ?>
                                <div class="spec-item">
                                    <img src="/assets/images/icons/gas-station.svg" alt="Brandstof" class="spec-icon" onerror="this.style.display='none'">
                                    <span class="spec-text"><?= htmlspecialchars($car['fuel_type']) ?></span>
                                </div>
                            <?php endif; ?>
                            <?php if (isset($car['transmission'])): ?>
                                <div class="spec-item">
                                    <img src="/assets/images/icons/car.svg" alt="Versnelling" class="spec-icon" onerror="this.style.display='none'">
                                    <span class="spec-text"><?= htmlspecialchars($car['transmission']) ?></span>
                                </div>
                            <?php endif; ?>
                            <?php if (isset($car['fuel_capacity'])): ?>
                                <div class="spec-item">
                                    <img src="/assets/images/icons/setting.svg" alt="Motorinhoud" class="spec-icon" onerror="this.style.display='none'">
                                    <span class="spec-text"><?= htmlspecialchars($car['fuel_capacity']) ?>L</span>
                                </div>
                            <?php endif; ?>
                            <?php if (isset($car['seats'])): ?>
                                <div class="spec-item">
                                    <img src="/assets/images/icons/profile-2user.svg" alt="Zitplaatsen" class="spec-icon" onerror="this.style.display='none'">
                                    <span class="spec-text"><?= htmlspecialchars($car['seats']) ?> zit</span>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php if (isset($car['year'])): ?>
                            <div class="car-year">
                                <img src="/assets/images/icons/calendar.svg" alt="Bouwjaar" class="year-icon" onerror="this.style.display='none'">
                                <span><?= htmlspecialchars($car['year']) ?></span>
                            </div>
                        <?php endif; ?>
                        <div class="rent-details">
                            <?php 
                            // Zorg ervoor dat de prijs altijd correct wordt geformatteerd
                            $price = isset($car['price_per_day']) ? (float)$car['price_per_day'] : (isset($car['price']) ? (float)$car['price'] : 0);
                            $formattedPrice = '€' . number_format($price, 2, ',', '.');
                            ?>
                            <span class="font-weight-bold"><?= $formattedPrice ?></span> / dag
                            <a href="/car-detail?id=<?= htmlspecialchars($car['id'] ?? '') ?>" class="button-primary">Bekijk nu</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <div class="show-more" style="text-align: center; margin: 30px 0;">
            <a href="/pages/aanbod.php" class="button-primary">Klik hier voor meer</a>
        </div>
    </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php" ?>