<?php require_once __DIR__ . "/../includes/header.php"; ?>

<main>
    <h1>Ons Team</h1>
    
    <div style="display: flex; flex-wrap: wrap; gap: 20px; justify-content: center; padding: 20px;">
        <!-- Teamlid 1 -->
        <div style="width: 250px; text-align: center; padding: 20px; background: white; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <img src="/assets/images/team/brian-mensah.png" alt="Brian Mensah" style="width: 150px; height: 150px; border-radius: 50%; object-fit: cover; margin-bottom: 15px;" onerror="this.src='/assets/images/placeholder.jpg';">
            <h3>Brian Mensah</h3>
            <p style="color: #3498db; font-weight: bold;">CEO & Oprichter</p>
            <p>Ervaren leider met passie voor auto's.</p>
        </div>

        <!-- Teamlid 2 -->
        <div style="width: 250px; text-align: center; padding: 20px; background: white; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <img src="/assets/images/team/jasper-van-den-brink.png" alt="Jasper van den Brink" style="width: 150px; height: 150px; border-radius: 50%; object-fit: cover; margin-bottom: 15px;" onerror="this.src='/assets/images/placeholder.jpg';">
            <h3>Jasper van den Brink</h3>
            <p style="color: #3498db; font-weight: bold;">Sales Manager</p>
            <p>Expert in klantrelaties en verkoop.</p>
        </div>

        <!-- Teamlid 3 -->
        <div style="width: 250px; text-align: center; padding: 20px; background: white; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <img src="/assets/images/team/lotte-de-graaf.png" alt="Lotte de Graaf" style="width: 150px; height: 150px; border-radius: 50%; object-fit: cover; margin-bottom: 15px;" onerror="this.src='/assets/images/placeholder.jpg';">
            <h3>Lotte de Graaf</h3>
            <p style="color: #3498db; font-weight: bold;">Technisch Specialist</p>
            <p>Zorgt voor perfect werkende auto's.</p>
        </div>

        <!-- Teamlid 4 -->
        <div style="width: 250px; text-align: center; padding: 20px; background: white; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <img src="/assets/images/team/youssef-amrani.png" alt="Youssef Amrani" style="width: 150px; height: 150px; border-radius: 50%; object-fit: cover; margin-bottom: 15px;" onerror="this.src='/assets/images/placeholder.jpg';">
            <h3>Youssef Amrani</h3>
            <p style="color: #3498db; font-weight: bold;">Marketing Manager</p>
            <p>Brengt ons verhaal naar buiten.</p>
        </div>
    </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>
