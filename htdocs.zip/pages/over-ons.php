<?php require_once __DIR__ . "/../includes/header.php" ?>
<main>
    <img src="/assets/images/banner.jpeg" alt="Rydr hoofdkantoor" width="1200" onerror="this.src='/assets/images/placeholder.jpg'">
    <h2>Over Rydr.</h2>
    <div class="grid">
        <div class="row">
            <p>Ons hoofdkantoor bevindt zich in het bruisende hart van Rotterdam, direct naast het Centraal Station.
                Hier combineren we technologie, design en klantgerichtheid onder één dak.</p>
            <p> In een modern pand met uitzicht op de skyline werken we elke dag aan de mobiliteit van morgen. Loop je
                een keer binnen? De koffie staat klaar.</p>
        </div>
        <div class="row">
            <img src="/assets/images/work-place.png" alt="Ons kantoor" width="400" onerror="this.src='/assets/images/placeholder.jpg'">
        </div>
    </div>
    <div class="row">
    <h2>Wat doen wij?</h2>
    <p>Wij helpen jou bij het vinden, vergelijken en kiezen van de perfecte auto voor jouw situatie. Of je nu op zoek bent naar een gezinsauto, een sportieve wagen of een zuinige stadsauto – wij staan voor je klaar met advies, tools en een ruim aanbod.</p>
    <div class="grid">
        <div class="row">
            <img src="/assets/images/icons/setting.svg" alt="Icoon" onerror="this.src='/assets/images/placeholder.jpg'">
            <h3>Onze missie</h3>
            <p>Onze missie is om te helpen bij het vinden van de juiste auto voor elke situatie.
                Ook willen we ervoor zorgen dat alle autos voldoen aan de huidige normen en regels.
                We willen er ook voor zorgen dat alle autos veilig en betrouwbaar zijn.
            </p>
        </div>
        <div class="row">
            <img src="/assets/images/icons/setting.svg" alt="Icoon" onerror="this.src='/assets/images/placeholder.jpg'">
            <h3>Onze aanpak</h3>
            <p>Wij bieden duidelijke informatie, filters en persoonlijk advies om de beste keuze te maken.
                We bieden ook een ruim aanbod van autos om uit te kiezen van offroaders
                tot aan supercars.
            </p>
        </div>
        <div class="row">
            <img src="/assets/images/icons/setting.svg" alt="Icoon" onerror="this.src='/assets/images/placeholder.jpg'">
            <h3>Onze belofte</h3>
            <p>Transparantie, betrouwbaarheid en klanttevredenheid staan bij ons voorop.
                Ook vinden wij uw feedback belangrijk om onze diensten te verbeteren.
            </p>
        </div>
    </div>
</div>

<h2>Ons team</h2>
<a href="ons-team" class="Button-team">Ons team</a>
</main>

<?php require_once __DIR__ . "/../includes/footer.php" ?>

<style>
    .Button-team {
        background-color: #3563e9;
        color: white;
        border-radius: 4px;
        padding: 10px 20px;
        max-width: fit-content;
        text-decoration: none;
    }
