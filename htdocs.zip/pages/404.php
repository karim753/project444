<?php require_once __DIR__ . "/../includes/header.php" ?>
<main>
    <h2>Deze pagina bestaat niet</h2>
    <a href="/">Ga terug naar de homepage</a>
</main>
<?php require_once __DIR__ . "/../includes/footer.php" ?>