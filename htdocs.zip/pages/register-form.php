<?php 
require_once __DIR__ . "/../includes/header.php";
?>
<style>
.error-message {
    background-color: #ffebee;
    color: #c62828;
    padding: 12px;
    border-radius: 4px;
    margin-bottom: 20px;
    border-left: 4px solid #c62828;
}

.message {
    background-color: #e8f5e9;
    color: #2e7d32;
    padding: 12px;
    border-radius: 4px;
    margin-bottom: 20px;
    border-left: 4px solid #2e7d32;
}

.account-form input[type="email"],
.account-form input[type="password"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ddd;
    border-radius: 4px;
    box-sizing: border-box;
}

.account-form input[type="submit"] {
    width: 100%;
    padding: 12px;
    background-color: #2196F3;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
}

.account-form input[type="submit"]:hover {
    background-color: #1976D2;
}

.login-link {
    text-align: center;
    margin-top: 15px;
}

.login-link a {
    color: #2196F3;
    text-decoration: none;
}

.login-link a:hover {
    text-decoration: underline;
}
</style>
<main>
    <form action="../actions/register.php" method="post" class="account-form">
        <h2>Maak een account aan</h2>
        <?php if (isset($_SESSION['error'])): ?>
            <div class="error-message">
                <?= $_SESSION['error'] ?>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
        <?php if (isset($_SESSION['message'])): ?>
            <div class="message">
                <?= $_SESSION['message'] ?>
            </div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>
        <label for="email">Uw e-mail</label>
        <input type="email" name="email" id="email" placeholder="johndoe@gmail.com" value="<?= isset($_SESSION['email']) ? htmlspecialchars($_SESSION['email']) : '' ?>" required autofocus>
        <label for="password">Uw wachtwoord</label>
        <input type="password" name="password" id="password" placeholder="Uw wachtwoord" required>
        <label for="confirm_password">Herhaal wachtwoord</label>
        <input type="password" name="confirm_password" id="confirm_password" placeholder="Herhaal uw wachtwoord" required>
        <input type="submit" value="Maak account aan" class="button-primary">
        <div class="login-link">
            <a href="/login-form" class="button-primary">Heb je al een account?</a>
        </div>
    </form>
</main>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>
