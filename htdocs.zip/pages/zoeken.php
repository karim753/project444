<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check for empty search query before any output
$searchQuery = trim($_GET['q'] ?? '');

if (empty($searchQuery)) {
    header('Location: /aanbod');
    exit();
}

// Now include other files after the potential redirect
require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../database/connection.php";

$searchResults = [];
$error = null;

try {
    // First check if the cars table exists
    $tableCheck = $pdo->query("SHOW TABLES LIKE 'cars'");
    if ($tableCheck->rowCount() === 0) {
        throw new Exception("De 'cars' tabel bestaat niet in de database.");
    }

    // Get column names to verify they exist
    $columns = [];
    $columnStmt = $pdo->query("DESCRIBE cars");
    while ($row = $columnStmt->fetch(PDO::FETCH_ASSOC)) {
        $columns[] = $row['Field'];
    }

    // Define searchable columns
    $searchableColumns = array_intersect(
        ['brand', 'model', 'type', 'fuel_type', 'transmission'],
        $columns
    );

    if (empty($searchableColumns)) {
        throw new Exception("Geen geschikte zoekvelden gevonden in de database.");
    }

    // Build the search query
    $searchTerm = "%$searchQuery%";
    $conditions = [];
    $params = [];
    
    foreach ($searchableColumns as $column) {
        $conditions[] = "$column LIKE ?";
        $params[] = $searchTerm;
    }
    
    $sql = "SELECT * FROM cars WHERE " . implode(" OR ", $conditions) . " ORDER BY brand, model";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $searchResults = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $error = "Database fout: " . $e->getMessage();
    error_log("Search error: " . $e->getMessage());
} catch (Exception $e) {
    $error = $e->getMessage();
    error_log("Search error: " . $e->getMessage());
}
?>

<main class="main-content">
    <div class="container">
        <h1 class="section-title">Zoekresultaten voor: <?= htmlspecialchars($searchQuery) ?></h1>
        
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <?php if (empty($searchResults)): ?>
            <p>Geen auto's gevonden voor '<?= htmlspecialchars($searchQuery) ?>'.</p>
            <a href="/aanbod" class="button-primary">Bekijk al onze auto's</a>
        <?php else: ?>
            <div class="cars">
                <?php foreach ($searchResults as $car): ?>
                    <div class="car-details">
                        <div class="car-brand">
                            <h3><?= htmlspecialchars($car['brand'] ?? 'Onbekend merk') ?></h3>
                            <div class="car-type">
                                <?= htmlspecialchars($car['model'] ?? 'Onbekend model') ?>
                            </div>
                        </div>
                        <?php 
                        $imagePath = !empty($car['image_url']) ? trim($car['image_url']) : 'assets/images/placeholder-car.png';
                        $imagePath = str_replace('\\', '/', $imagePath);
                        $imagePath = ltrim($imagePath, '/');
                        $fullPath = $_SERVER['DOCUMENT_ROOT'] . '/' . $imagePath;
                        if (!file_exists($fullPath)) {
                            $imagePath = 'assets/images/placeholder-car.png';
                        }
                        ?>
                        <img src="/<?= htmlspecialchars($imagePath) ?>" 
                             alt="<?= htmlspecialchars(($car['brand'] ?? '') . ' ' . ($car['model'] ?? '')) ?>" 
                             onerror="this.src='/assets/images/placeholder-car.png'" 
                             style="width: 100%; height: 200px; object-fit: cover;">
                        <div class="car-specification">
                            <?php if (!empty($car['fuel_type'])): ?>
                                <div class="spec-item">
                                    <img src="/assets/images/icons/gas-station.svg" alt="Brandstof" class="spec-icon">
                                    <span class="spec-text"><?= htmlspecialchars($car['fuel_type']) ?></span>
                                </div>
                            <?php endif; ?>
                            <?php if (!empty($car['transmission'])): ?>
                                <div class="spec-item">
                                    <img src="/assets/images/icons/car.svg" alt="Versnelling" class="spec-icon">
                                    <span class="spec-text"><?= htmlspecialchars($car['transmission']) ?></span>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="rent-details">
                            <?php 
                            $price = isset($car['price_per_day']) ? (float)$car['price_per_day'] : (isset($car['price']) ? (float)$car['price'] : 0);
                            $formattedPrice = '€' . number_format($price, 2, ',', '.');
                            ?>
                            <span class="font-weight-bold"><?= $formattedPrice ?></span> / dag
                            <a href="/car-detail?id=<?= htmlspecialchars($car['id'] ?? '') ?>" class="button-primary">Bekijk nu</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</main>

<?php require_once __DIR__ . "/../includes/footer.php" ?>

<style>
.search-form {
    display: flex;
    align-items: center;
    position: relative;
    max-width: 400px;
    width: 100%;
}

#searchInput {
    width: 100%;
    padding: 10px 40px 10px 15px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 14px;
}

.search-button {
    position: absolute;
    right: 5px;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    cursor: pointer;
    padding: 5px;
}

.search-icon {
    width: 20px;
    height: 20px;
}

.alert {
    padding: 15px;
    margin-bottom: 20px;
    border: 1px solid transparent;
    border-radius: 4px;
}

.alert-danger {
    color: #721c24;
    background-color: #f8d7da;
    border-color: #f5c6cb;
}

.cars {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

.car-details {
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 15px;
    transition: transform 0.3s ease;
}

.car-details:hover {
    transform: translateY(-5px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.button-primary {
    display: inline-block;
    background-color: #007bff;
    color: white;
    padding: 8px 16px;
    border-radius: 4px;
    text-decoration: none;
    margin-top: 10px;
    text-align: center;
}

.button-primary:hover {
    background-color: #0056b3;
}
</style>
