<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../database/connection.php';

// Get car ID from query parameters
$carId = filter_input(INPUT_GET, 'car_id', FILTER_VALIDATE_INT);

if (!$carId) {
    http_response_code(400);
    echo json_encode(['error' => 'Ongeldige auto ID']);
    exit;
}

try {
    // Get all bookings for this car
    $stmt = $pdo->prepare("SELECT start_date, end_date FROM bookings WHERE car_id = ? AND end_date >= CURDATE()");
    $stmt->execute([$carId]);
    $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Generate events for booked dates (in real app, you'd query the database)
    $events = [];
    
    // Add booked dates as unavailable
    foreach ($bookings as $booking) {
        $events[] = [
            'title' => 'Bezet',
            'start' => $booking['start_date'],
            'end' => $booking['end_date'],
            'display' => 'background',
            'color' => '#ffebee',
            'textColor' => '#c62828',
            'status' => 'booked'
        ];
    }
    
    // For demo purposes, mark some dates as available
    // In a real app, you would query your database for available dates
    $startDate = new DateTime();
    $endDate = (new DateTime())->modify('+3 months');
    
    while ($startDate <= $endDate) {
        // Skip weekends for demo (in real app, check against your availability rules)
        if ($startDate->format('N') < 6) { // Monday to Friday
            $events[] = [
                'title' => 'Beschikbaar',
                'start' => $startDate->format('Y-m-d'),
                'color' => '#e8f5e9',
                'textColor' => '#2e7d32',
                'status' => 'available'
            ];
        }
        $startDate->modify('+1 day');
    }
    
    echo json_encode($events);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Databasefout: ' . $e->getMessage()]);
}
