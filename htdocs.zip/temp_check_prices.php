<?php
require_once __DIR__ . "/database/connection.php";

// Query om auto's met hun prijzen op te halen
$query = "SELECT id, brand, model, price, price_per_day FROM cars";
$stmt = $pdo->query($query);
$cars = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<pre>";
print_r($cars);
echo "</pre>";
