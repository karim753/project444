<?php
// Lijst van bestanden die moeten worden bijgewerkt
$files = [
    'pages/over-ons.php',
    'pages/ons-team.php',
    'pages/ons-aanbod.php',
    'pages/mijn-account.php',
    'pages/hulp-nodig.php',
    'pages/home.php',
    'pages/404.php',
    'pages/aanbod_new.php',
    'pages/aanbod.php'
];

foreach ($files as $file) {
    $fullPath = __DIR__ . '/' . $file;
    if (file_exists($fullPath)) {
        $content = file_get_contents($fullPath);
        
        // Vervang header includes
        $content = preg_replace(
            '/require\s+[\'\"]includes\/header\.php[\'\"]/i', 
            'require_once __DIR__ . "/../includes/header.php"', 
            $content
        );
        
        // Vervang footer includes
        $content = preg_replace(
            '/require\s+[\'\"]includes\/footer\.php[\'\"]/i', 
            'require_once __DIR__ . "/../includes/footer.php"', 
            $content
        );
        
        // Sla het bestand alleen op als er wijzigingen zijn
        if ($content !== file_get_contents($fullPath)) {
            file_put_contents($fullPath, $content);
            echo "Bijgewerkt: $file\n";
        } else {
            echo "Geen wijzigingen nodig: $file\n";
        }
    } else {
        echo "Bestand niet gevonden: $file\n";
    }
}

echo "\nKlaar! Alle bestanden zijn bijgewerkt.\n";
?>
